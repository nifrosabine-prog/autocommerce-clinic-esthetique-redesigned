# Checklist go-live unique

Projet : __________________________
Clinique : ________________________
VPS cible : _______________________
Version applicative : _____________
Date : ____________________________

## Gate unique

- [ ] `.env.production` final validé
- [ ] `DEPLOYMENT_MODE=internal_single_clinic`
- [ ] `CLINIC_ID` défini
- [ ] `PUBLIC_CLINIC_ID=CLINIC_ID` si public activé
- [ ] `SOCIAL_WEBHOOK_CLINIC_ID=CLINIC_ID` si webhooks activés
- [ ] `CORS_ORIGINS` strict et réel
- [ ] `REFRESH_COOKIE_DOMAIN` réel ou vide assumé
- [ ] `docker compose up -d` complet réussi
- [ ] `alembic upgrade head` réussi
- [ ] `/health` OK
- [ ] `/ready` OK
- [ ] login OK
- [ ] MFA OK
- [ ] refresh OK
- [ ] logout OK
- [ ] booking public -> validation privée OK
- [ ] RBAC par rôle OK
- [ ] isolation clinique OK
- [ ] worker OK
- [ ] beat OK
- [ ] webhook réel ou sandbox OK
- [ ] backup chiffré OK
- [ ] HMAC OK
- [ ] restauration isolée OK
- [ ] comptages/intégrité OK
- [ ] procédure minutée OK
- [ ] logs structurés OK
- [ ] `request_id` / `correlation_id` OK
- [ ] alertes process OK
- [ ] alertes disque OK
- [ ] alertes backup OK
- [ ] alertes erreur applicative OK
- [ ] alertes worker/beat OK
- [ ] rollback testé OK
- [ ] documentation finale relue OK

## Signatures

Exploitant : ______________________
Date/heure : ______________________

Responsable clinique : ____________
Date/heure : ______________________

Décision finale : GO / NO-GO
