#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════
# AutoCommerce Clinic — Sauvegarde hors-site (rsync + SSH, mono-VPS)
# ═══════════════════════════════════════════════════════════════════════
# Synchronise les volumes Docker `clinic_backups` (dumps pg + archives
# données) et `clinic_data` (photos / uploads / branding) vers une cible
# distante, en miroir : `--delete` retire côté distant ce qui a été purgé
# localement par backup.sh (rétention RETENTION_DAYS).
#
# Prérequis :
#   - Authentification SSH par clé (jamais de mot de passe) :
#       ssh-keygen -t ed25519
#       ssh-copy-id backup@nas.local
#   - Copier deploy/offsite.env.example vers /etc/autocommerce/offsite.env
#     (chmod 600) et renseigner OFFSITE_TARGET.
#
# Usage :
#   scripts/offsite_sync.sh            # synchronisation réelle
#   scripts/offsite_sync.sh -n         # dry-run (ne modifie rien)
#   OFFSITE_DRY_RUN=true scripts/offsite_sync.sh   # idem via env
#
# Codes de sortie : 0 = ok · 1 = échec rsync · 2 = configuration invalide
#                   3 = une autre instance tourne déjà (flock)
# (le code rsync 24 « vanished files » est toléré et journalisé)
# ═══════════════════════════════════════════════════════════════════════
set -euo pipefail

PREFIX="[offsite]"
LOG="${OFFSITE_LOG:-/var/log/autocommerce_offsite.log}"
LOCKFILE="${OFFSITE_LOCKFILE:-/var/lock/autocommerce_offsite.lock}"

log() { printf '%s %s %s\n' "$(date -u +%FT%TZ)" "$PREFIX" "$*" | tee -a "$LOG"; }

# ── Alerte en cas d'échec (webhook générique : Slack, Discord…) ────────
alert() {
  local msg="$1"
  log "ALERTE: $msg"
  if [ -n "${OFFSITE_WEBHOOK_URL:-}" ]; then
    if curl -fsS -m 10 -X POST -H 'Content-Type: application/json' \
         -d "{\"text\":\"$(printf '%s' "$msg" | sed 's/"/\\"/g')\"}" \
         "$OFFSITE_WEBHOOK_URL" >/dev/null 2>&1; then
      log "Alerte webhook envoyée"
    else
      log "Échec de l'envoi de l'alerte webhook (URL injoignable)"
    fi
  fi
}

# ── Rotation du journal (au-delà de 20 Mo) ─────────────────────────────
if [ -f "$LOG" ] && [ "$(wc -c < "$LOG" 2>/dev/null || echo 0)" -gt 20971520 ]; then
  mv "$LOG" "$LOG.1"
  : > "$LOG"
  log "Journal rotaté (ancien: ${LOG}.1)"
fi

# ── Configuration optionnelle (mêmes variables que l'environnement) ────
CONFIG_FILE="${OFFSITE_CONFIG:-/etc/autocommerce/offsite.env}"
if [ -r "$CONFIG_FILE" ]; then
  # shellcheck disable=SC1090
  set -a; . "$CONFIG_FILE"; set +a
  log "Configuration chargée: $CONFIG_FILE"
fi

TARGET="${OFFSITE_TARGET:-}"
if [ -z "$TARGET" ]; then
  log "ERREUR: OFFSITE_TARGET requis (ex. backup@nas.local:/volume/autocommerce)"
  exit 2
fi

DRY_RUN=false
if [ "${1:-}" = "-n" ] || [ "${OFFSITE_DRY_RUN:-false}" = "true" ]; then
  DRY_RUN=true
fi

# Exclusions supplémentaires (séparées par des virgules dans la config).
EXTRA_EXCLUDES=()
if [ -n "${OFFSITE_EXCLUDE_EXTRA:-}" ]; then
  IFS=',' read -r -a _pats <<< "$OFFSITE_EXCLUDE_EXTRA"
  for pat in "${_pats[@]}"; do
    [ -n "$pat" ] && EXTRA_EXCLUDES+=(--exclude="$pat")
  done
fi

RSYNC_OPTS=(-a --delete --partial --numeric-ids \
  --exclude='*.tmp' --exclude='lost+found' \
  "${EXTRA_EXCLUDES[@]}" --info=stats1)
[ "$DRY_RUN" = true ] && RSYNC_OPTS+=(--dry-run)

# ── Verrou : jamais deux synchronisations simultanées ──────────────────
exec 9>"$LOCKFILE"
if ! flock -n 9; then
  log "Une autre instance tourne déjà (lock: $LOCKFILE) — abandon"
  exit 3
fi

# ── Résolution des sources (volumes Docker ou chemins explicites) ──────
resolve_sources() {
  local found=() mp vol
  if [ -n "${OFFSITE_SOURCES:-}" ]; then
    for s in $OFFSITE_SOURCES; do
      [ -d "$s" ] && found+=("$s")
    done
  else
    for vol in clinic_backups clinic_data; do
      mp="$(docker volume inspect --format '{{.Mountpoint}}' "$vol" 2>/dev/null || true)"
      [ -n "$mp" ] && [ -d "$mp" ] && found+=("$mp")
    done
    for v in "${found[@]}"; do log "Volume Docker détecté: $v"; done
  fi
  if [ "${#found[@]}" -eq 0 ]; then
    log "ERREUR: aucune source — volumes Docker clinic_backups/clinic_data introuvables, ou OFFSITE_SOURCES non défini"
    return 1
  fi
  SOURCES=("${found[@]}")
}
resolve_sources

# ── Synchronisation ────────────────────────────────────────────────────
log "Démarrage (dry-run=$DRY_RUN) — cible: $TARGET"
total=0; failed=0
for src in "${SOURCES[@]}"; do
  name="$(basename "$src")"
  log "rsync ${name} → ${TARGET}/${name}/"
  set +e
  rsync "${RSYNC_OPTS[@]}" "$src/" "$TARGET/$name/" 2>>"$LOG"
  rc=$?
  set -e
  total=$((total + 1))
  if [ "$rc" -eq 0 ] || [ "$rc" -eq 24 ]; then
    log "OK ${name} (rsync exit=$rc)"
  else
    failed=$((failed + 1))
    log "ÉCHEC ${name} (rsync exit=$rc)"
  fi
done

if [ "$failed" -ne 0 ]; then
  alert "Sauvegarde hors-site : ${failed}/${total} volume(s) en échec — cible ${TARGET}"
  exit 1
fi
if [ "$DRY_RUN" = true ]; then
  log "Dry-run terminé — aucune donnée envoyée"
  exit 0
fi
log "Synchronisation hors-site terminée (${total}/${total} volume(s) OK)"
