# Dossier de preuves v3

Les journaux de ce dossier sont des extraits de validation exécutés dans l’environnement de recette. Ils ne contiennent pas les secrets de recette, les clés TLS privées, les tokens d’accès ni les bases de données locales. Les preuves OpenAI utilisent uniquement un prompt synthétique non médical et attestent une intégration configurable de test.
