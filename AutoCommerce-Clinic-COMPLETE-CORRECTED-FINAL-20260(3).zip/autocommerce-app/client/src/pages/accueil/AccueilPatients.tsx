import { useCallback, useEffect, useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Search, UserCheck, FileText, RefreshCw } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Spinner } from '@/components/ui/spinner';
import { toast } from 'sonner';
import { accueilApi, type AccueilAppointment } from '@/lib/api';

const labels: Record<string, string> = {
  planifie: 'Planifié', confirme: 'Confirmé', arrive: 'Arrivé', accord: 'Accord reçu',
  no_show: 'Absent', annule: 'Annulé', termine: 'Terminé',
};

export default function AccueilPatients() {
  const [, setLocation] = useLocation();
  const [query, setQuery] = useState('');
  const [appointments, setAppointments] = useState<AccueilAppointment[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const response = await accueilApi.list({ q: query || undefined });
      setAppointments(response.data || []);
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Impossible de charger l’accueil des patients');
    } finally {
      setLoading(false);
    }
  }, [query]);

  useEffect(() => { void load(); }, [load]);

  const markArrived = async (appointment: AccueilAppointment) => {
    try {
      const response = await accueilApi.markArrived(appointment.id);
      toast.success('Arrivée enregistrée.');
      setLocation(`/medical-record/${response.data.patient_id}?rdvId=${appointment.id}&episodeId=${response.data.episode_id || ''}`);
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Impossible d’enregistrer l’arrivée');
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col justify-between gap-3 md:flex-row md:items-center">
          <div>
            <h1 className="text-3xl font-bold">Accueil des patients</h1>
            <p className="text-muted-foreground">Depuis cette page, confirmez l’arrivée puis ouvrez directement le dossier patient.</p>
          </div>
          <Button variant="outline" onClick={() => void load()}><RefreshCw className="mr-2 h-4 w-4" /> Actualiser</Button>
        </div>
        <Card>
          <CardContent className="pt-6">
            <div className="flex gap-2">
              <Search className="mt-2 h-4 w-4 text-muted-foreground" />
              <Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Nom, téléphone, référence ou numéro de rendez-vous" />
            </div>
          </CardContent>
        </Card>
        {loading ? <div className="flex justify-center py-12"><Spinner /></div> : appointments.length === 0 ? (
          <Card><CardContent className="py-10 text-center text-muted-foreground">Aucun rendez-vous trouvé.</CardContent></Card>
        ) : (
          <div className="space-y-3">
            {appointments.map((appointment) => (
              <Card key={appointment.id}>
                <CardContent className="flex flex-col gap-4 p-5 md:flex-row md:items-center md:justify-between">
                  <div>
                    <div className="flex flex-wrap items-center gap-2"><span className="font-semibold">{appointment.patient_nom}</span><Badge variant="outline">{labels[appointment.statut] || appointment.statut}</Badge></div>
                    <p className="text-sm text-muted-foreground">{new Date(appointment.date_heure_debut).toLocaleString('fr-FR')} · {appointment.acte_nom || 'Acte non précisé'}</p>
                    <p className="text-xs text-muted-foreground">{appointment.reference || `RDV #${appointment.id}`} · {appointment.telephone || 'Téléphone non renseigné'} · {appointment.source}</p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {(appointment.statut === 'planifie' || appointment.statut === 'confirme') && <Button onClick={() => void markArrived(appointment)}><UserCheck className="mr-2 h-4 w-4" /> Patient arrivé</Button>}
                    {(appointment.statut === 'arrive' || appointment.statut === 'accord') && <Button variant="secondary" onClick={() => setLocation(`/medical-record/${appointment.patient_id}?rdvId=${appointment.id}`)}><FileText className="mr-2 h-4 w-4" /> Ouvrir le dossier</Button>}
                    <Link href={`/patients/${appointment.patient_id}`}><Button variant="outline">Fiche patient</Button></Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
