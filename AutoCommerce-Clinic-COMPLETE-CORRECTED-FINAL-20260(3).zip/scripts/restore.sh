#!/bin/sh
# Restauration AutoCommerce Clinic (reprise après sinistre).
# Usage (depuis l'hôte, avec la stack Docker démarrée) :
#   docker compose -f docker-compose.production.yml --env-file deploy/production.env \
#     exec -T backup sh /scripts/restore.sh <dump.dump> [archive_donnees.tar.gz]
# Exemple :
#   ... exec -T backup sh /scripts/restore.sh \
#         clinic_production_20260906T120000Z.dump \
#         clinic_production_20260906T120000Z_data.tar.gz
#
# ATTENTION : écrase la base ET les données actuelles. Pour une
# restauration cohérente, arrêter d'abord les services qui écrivent :
#   docker compose -f docker-compose.production.yml stop api worker beat
# ... puis les relancer après la restauration :
#   docker compose -f docker-compose.production.yml start api worker beat
# Si une copie exacte des données est requise, vider $DATA_DIR (ex : rm -rf
# /data/*) avant la restauration — l'extraction par-dessus ne supprime pas
# les fichiers absents de l'archive.
set -eu

BACKUP_DIR="${BACKUP_DIR:-/backups}"
DATA_DIR="${DATA_DIR:-/data}"
GRACE="${RESTORE_GRACE_SECONDS:-5}"

if [ $# -lt 1 ]; then
  echo "Usage: $0 <dump.dump> [archive_donnees.tar.gz]" >&2
  exit 1
fi

DUMP_FILE="${BACKUP_DIR}/$1"
DATA_FILE=""
if [ $# -ge 2 ]; then
  DATA_FILE="${BACKUP_DIR}/$2"
  [ -f "$DATA_FILE" ] || { echo "Archive de données introuvable: $DATA_FILE" >&2; exit 1; }
fi

[ -f "$DUMP_FILE" ] || {
  echo "Fichier introuvable: $DUMP_FILE" >&2
  echo "Sauvegardes disponibles :" >&2
  ls -1 "$BACKUP_DIR" 2>/dev/null || echo "  (aucune)" >&2
  exit 1
}

echo "[restore] base : ${DUMP_FILE} → ${POSTGRES_DB} sur ${PGHOST}"
if [ -n "$DATA_FILE" ]; then
  echo "[restore] données : ${DATA_FILE} → ${DATA_DIR}"
fi
echo "[restore] annulez avec Ctrl+C dans ${GRACE}s si ce n'est pas voulu..." >&2
sleep "$GRACE"

pg_restore -h "${PGHOST}" -U "${POSTGRES_USER}" -d "${POSTGRES_DB}" \
  --clean --if-exists --no-owner --no-privileges "$DUMP_FILE"
echo "[restore] base restaurée"

if [ -n "$DATA_FILE" ]; then
  mkdir -p "$DATA_DIR"
  cd "$DATA_DIR"
  tar -xzf "$DATA_FILE"
  echo "[restore] données restaurées dans ${DATA_DIR}"
fi

echo "[restore] terminé"
