# Rapport d’exécution — Bloc B
## Antécédents, allergies, traitements et contre-indications

**Projet :** AutoCommerce Clinic / Clinical Core  
**Date :** 10 septembre 2026  
**Base :** copie de travail issue de l’archive Bloc A PASS.

## Objectif

Structurer progressivement les données médicales du patient sans inventer d’information et sans supprimer les champs historiques existants.

## Décision d’architecture

Une table unique `patients_faits_medicaux` est utilisée pour les faits structurés du patient. Le champ `type_fait` distingue :

- `antecedent_medical` ;
- `antecedent_chirurgical` ;
- `antecedent_anesthesique` ;
- `antecedent_familial` ;
- `allergie` ;
- `traitement` ;
- `contre_indication`.

Les données métier sont stockées dans `donnees_enc`, chiffrées côté backend. Chaque entrée conserve la clinique, le patient, l’épisode éventuel, l’auteur authentifié, la classification `MEDICAL_SENSITIVE`, la source, le statut de vérification et l’état actif.

## Migration des données historiques

Aucune conversion automatique des champs existants `allergies_enc`, `antecedents_medicaux_enc` ou `contre_indications_enc` n’est effectuée. Ces textes peuvent contenir des informations ambiguës ; les transformer automatiquement en données structurées validées serait médicalement dangereux. Une migration future devra être explicitement pilotée par un professionnel et marquée `MIGRATED` / `PENDING_VERIFICATION` si elle est réalisée.

## API ajoutée

- `POST /api/private/patients/{patient_id}/medical-facts`
- `GET /api/private/patients/{patient_id}/medical-facts`
- `DELETE /api/private/patients/{patient_id}/medical-facts/{fact_id}`
- mêmes routes sous `/api/v1` pour compatibilité.

Le schéma Pydantic refuse les champs supplémentaires : `author_id`, `auteur_id`, `practitioner_id` et `user_id` ne peuvent pas être utilisés comme preuve d’identité. L’auteur est déterminé par l’utilisateur authentifié.

## Permissions

- **Médecin :** créer, lire et désactiver logiquement ses faits médicaux dans sa clinique.
- **Assistante, esthéticienne et autres rôles :** refus backend.
- **Cross-tenant :** patient d’une autre clinique refusé.
- **Suppression :** soft-delete uniquement, aucune suppression physique.
- **Audit :** création, lecture et soft-delete journalisés dans `AuditLogMedical`.

## Migration Alembic

Migration : `20260910_patient_medical_facts`  
Dépendance : `20260910_consultations_medicales`  
État vérifié : `20260910_patient_medical_facts (head)`.

## Validation

- Tests Bloc B : réussis.
- Tests Bloc A et sécurité ciblée : réussis.
- Total de la validation ciblée : **45 tests réussis**.
- Smoke HTTP des routes privées et `/api/v1` : **PASS**, réponse `401` attendue sans authentification.
- Chiffrement des données : vérifié par test.
- Audit : vérifié par test.
- Cross-tenant : vérifié par test.
- Soft-delete : vérifié par test.
- Conservation des données historiques : vérifiée par conception ; aucune migration destructive.

# Verdict : PASS — Bloc B

Le Bloc B est validé dans la copie de travail. Les Blocs C à J n’ont pas été exécutés dans cette livraison.
