from __future__ import annotations

import json
import os
from datetime import datetime, timezone

import requests

BASE = os.environ.get("BUYER_API_BASE", "http://127.0.0.1:8100/api/v1")
patient_id = int(os.environ.get("BUYER_PATIENT_ID", "10"))
acte_id = int(os.environ.get("BUYER_ACTE_ID", "10"))
praticien_id = int(os.environ.get("BUYER_PRATICIEN_ID", "2"))
email = "medecin@clinique-esthetique.tn"
password = os.environ["QA_MEDECIN_PASSWORD"]

session = requests.Session()
login = session.post(f"{BASE}/auth/login", json={"identifier": email, "password": password}, timeout=20)
print("login", login.status_code)
if not login.ok:
    raise SystemExit(1)
session.headers.update({"Authorization": f"Bearer {login.json()['access_token']}"})
response = session.post(
    f"{BASE}/patients/{patient_id}/dossiers",
    json={
        "praticien_id": praticien_id,
        "acte_id": acte_id,
        "date_acte": datetime.now(timezone.utc).isoformat(),
        "observations": "Reproduction acheteur",
        "satisfaction_patient": 5,
    },
    timeout=30,
)
print(response.status_code, json.dumps(response.json(), ensure_ascii=False))
raise SystemExit(0 if response.ok else 1)
