# Rapport Blocs 2 à 5 — RBAC, accueil, workspace et transitions

**Projet :** AutoCommerce Clinic  
**Environnement :** recette locale PostgreSQL 16 + Redis 7  
**Date :** 10 septembre 2026

## Conclusion

Les Blocs 2 à 5 ont été audités, renforcés et validés sans régression détectée dans la suite existante.

Le projet disposait déjà d’une base solide pour le RBAC, l’accueil et le workspace. Les corrections appliquées ont ciblé les écarts fonctionnels identifiés plutôt que de reconstruire les modules existants.

## Bloc 2 — RBAC et confidentialité

La matrice backend existante a été conservée et vérifiée. Elle distingue notamment les droits médicaux, financiers, photos, notes privées, interventions, prix et paiements.

Le backend continue de vérifier la clinique, la portée de l’intervention et l’affectation du professionnel. Les tests existants de sécurité RBAC, d’isolation multi-clinique et de confidentialité sont restés passants.

Une correction importante a été appliquée dans les transitions d’actes : le rôle `admin` technique ne peut plus valider médicalement un acte. La validation médicale est réservée au médecin et à la direction.

## Bloc 3 — Accueil et agenda

Le parcours existant a été audité et conservé :

```text
arrivée → présence confirmée → accord d’examen → ouverture/réutilisation de l’épisode
```

Les routes d’accueil continuent de distinguer ces trois étapes. Les événements, absences, remplacements et recherches de doublons restent couverts par les services et tests existants.

Aucune modification de schéma n’a été nécessaire.

## Bloc 4 — Workspace

Le workspace est bien relié à `/workspace` et différencie les cartes selon le rôle connecté.

Une carte incorrecte a été supprimée pour les rôles médecin, esthéticienne et prestataire : elle affichait « Patients arrivés » avec un compteur fixe à zéro et pointait vers `/accueil`, une route inaccessible au prestataire. Ces rôles voient maintenant uniquement une action réelle : leurs interventions affectées vers `/clinical-ops`.

Le workspace assistante conserve les cartes patients attendus et patients arrivés. La direction et l’administration conservent les cartes épisodes ouverts et rendez-vous à traiter.

## Bloc 5 — Interventions et transitions

Les routes épisodes ont été renforcées :

- seuls les professionnels de soin et la direction peuvent proposer un acte ;
- un professionnel ne peut agir que sur sa propre intervention ;
- le professionnel ne peut pas modifier le tarif catalogue : son acte utilise le prix de référence ;
- la direction peut fournir un prix convenu ;
- le rôle admin technique ne peut pas valider médicalement ;
- la validation financière exige désormais une validation médicale préalable ;
- les validations répétées sont idempotentes ;
- les interventions et lignes d’actes sont systématiquement vérifiées dans l’épisode et la clinique.

Nouveaux endpoints de transition :

```text
POST /episodes/{episode_id}/interventions/{intervention_id}/demarrer
POST /episodes/{episode_id}/interventions/{intervention_id}/actes/{acte_line_id}/realiser
POST /episodes/{episode_id}/interventions/{intervention_id}/a-valider
POST /episodes/{episode_id}/interventions/{intervention_id}/cloturer
```

Le parcours est maintenant contrôlé :

```text
planifiee
→ en_cours
→ actes réalisés
→ a_valider
→ terminee
```

Une intervention ne peut pas démarrer sans acte ni sans validations médicale et financière. Un acte ne peut pas être réalisé sans ces deux validations. La clôture exige que tous les actes soient réalisés et que l’intervention soit passée par `a_valider`.

Les actions répétées retournent l’état courant au lieu de créer une double opération.

## Tests ajoutés

Nouveau fichier : `api-server/tests/test_blocs2_5_hardening.py`.

Les tests vérifient :

- impossibilité pour un professionnel de modifier le tarif catalogue ;
- parcours complet d’une intervention ;
- exigence de validation médicale avant validation financière ;
- absence de carte workspace pointant vers une route inaccessible au prestataire.

## Validation globale

| Validation | Résultat |
|---|---:|
| Tests ciblés Blocs 2 à 5 | **73 réussis** |
| Suite backend complète | **704 réussis, 1 ignoré** |
| Contrôle TypeScript | Réussi |
| Tests frontend | Réussis |
| Build Vite | Réussi |
| Alembic `current` | `20260909_suivi_rdv_link` |
| Alembic `heads` | Une seule tête : `20260909_suivi_rdv_link` |
| PostgreSQL cluster 16/main | Actif et en ligne sur le port 5432 |
| Redis | Actif, `PONG` confirmé |

Le service générique `postgresql` peut apparaître comme `inactive` alors que le cluster réel `postgresql@16-main` est actif et en ligne. La vérification `pg_lsclusters` confirme le cluster opérationnel.

## Migration

Aucune migration supplémentaire n’a été créée. Les changements portent sur les contrôles applicatifs, les routes de transitions, le workspace et les tests. La chaîne Alembic conserve une tête unique.

## Limites restantes

La validation a été effectuée au niveau backend, tests frontend, TypeScript, build et services de recette. Un parcours navigateur manuel avec comptes utilisateurs réels reste recommandé avant un déploiement production.

La clôture d’intervention vérifie les actes réalisés et la transition `a_valider`. Les exigences documentaires spécifiques à chaque protocole clinique — compte rendu détaillé, photos finales obligatoires, suivi post-acte selon l’acte — devront être raccordées dans les blocs cliniques suivants si elles ne sont pas déjà exigées par le protocole métier concerné.
