# Manifeste de livraison V2.1

Cette archive est conçue pour un déploiement **mono-clinique / mono-VPS**. Les valeurs d’environnement et les secrets restent à fournir par le client.

| Contrôle | Valeur par défaut | Effet |
|---|---:|---|
| `LLM_ENABLED` | `false` | Le mode déterministe par règles reste prioritaire. |
| `MEDICAL_AI_PROVIDER_APPROVED` | `false` | Aucun flux médical vers un fournisseur IA externe. |
| `WHATSAPP_ENABLED` | `false` | Aucun envoi réel sans configuration explicite. |
| `WA_ALLOW_DEV_MODE` | `false` | Le mode simulé doit être autorisé explicitement hors production. |
| `PUBLIC_ROUTES_ENABLED` | `false` | Les routes publiques sont opt-in. |
| `WEBHOOKS_ENABLED` | `false` | Les webhooks sont désactivés par défaut et fail-closed. |

Aucune donnée réelle de patient, aucun secret et aucun fichier `.env` de production ne doivent être ajoutés à cette archive.
