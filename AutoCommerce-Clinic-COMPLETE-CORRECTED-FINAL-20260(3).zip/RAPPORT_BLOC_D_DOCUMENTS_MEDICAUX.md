# Rapport d’exécution — Bloc D
## Documents médicaux du patient

**Projet :** AutoCommerce Clinic / Clinical Core  
**Date :** 10 septembre 2026  
**Base :** archive Bloc C PASS.

## Architecture

Le projet possédait déjà un stockage chiffré utilisé par les photos cliniques. Le Bloc D réutilise les helpers de chiffrement existants et le répertoire privé `uploads/medical-documents/{clinic_id}/{patient_id}`. Aucun fichier médical n’est exposé par une route publique.

Le nouveau modèle `DocumentMedicalPatient` conserve le patient, l’importateur backend, les liens consultation/intervention, le nom sûr, le MIME, la classification `EXTERNAL_MEDICAL_DOCUMENT`, la description chiffrée, le chemin chiffré, le hash SHA-256, la taille et l’état logique.

## API

- `POST /api/private/patients/{patient_id}/medical-documents` ;
- `GET /api/private/patients/{patient_id}/medical-documents` ;
- `GET /api/private/patients/{patient_id}/medical-documents/{document_id}/download` ;
- `DELETE /api/private/patients/{patient_id}/medical-documents/{document_id}` ;
- mêmes routes sous `/api/v1`.

Les documents acceptés sont limités à PDF, JPEG, PNG et texte brut, avec une taille maximale de 25 Mo. Le nom de fichier est neutralisé par `Path.name`. Le fichier stocké est chiffré et porte une extension `.enc`.

## Permissions et audit

L’import, la lecture et la suppression logique sont réservés au médecin dans sa clinique. Les contrôles patient/clinique sont backend et refusent les accès cross-tenant sans révéler l’existence du patient. La lecture déchiffre le fichier puis recalcule le SHA-256 avant restitution. La suppression est logique et ne supprime pas physiquement le fichier. Upload, liste, lecture, et soft-delete sont journalisés dans `AuditLogMedical`.

## Validation

La suite Bloc D et les régressions des Blocs A à C totalise **51 tests réussis**. Les tests couvrent le stockage chiffré, la restitution identique, le hash, l’audit, le refus MIME, les rôles non médicaux, le cross-tenant et le soft-delete. `alembic heads` confirme `20260910_documents_medicaux_patients`. Les routes privées répondent `401` sans authentification. L’URL non-API `/medical-documents/1` retourne uniquement le shell HTML frontend et aucun document médical ; la smoke validation de frontière privée/publique est PASS.

# Verdict : PASS — Bloc D

Les Blocs E à J n’ont pas été exécutés dans cette livraison.
