from __future__ import annotations

import json
import os
from pathlib import Path

import requests

BASE = "http://127.0.0.1:8180/api/v1"
REPORT = Path("/home/ubuntu/aesthetic_runtime_audit/BUYER_SECURITY_SMOKE_REPORT.json")


def login(identifier: str, password: str) -> requests.Session:
    session = requests.Session()
    response = session.post(f"{BASE}/auth/login", json={"identifier": identifier, "password": password}, timeout=20)
    if response.status_code != 200:
        raise RuntimeError(f"login failed {identifier}: {response.status_code}")
    session.headers.update({"Authorization": f"Bearer {response.json()['access_token']}"})
    return session


def check(name: str, response: requests.Response, expected: int) -> dict:
    return {"name": name, "status": response.status_code, "expected": expected, "ok": response.status_code == expected}


def main() -> int:
    results = []
    results.append(check("anonymous_private_rejected", requests.get(f"{BASE}/patients", timeout=20), 401))
    results.append(check("invalid_login_generic_rejected", requests.post(f"{BASE}/auth/login", json={"identifier": "unknown@buyer.invalid", "password": "invalid"}, timeout=20), 401))

    assistant = login("assistante@clinique-esthetique.tn", os.environ["QA_ASSISTANTE_PASSWORD"])
    results.append(check("clinic_role_cannot_open_super_admin", assistant.get(f"{BASE}/super-admin/dashboard", timeout=20), 403))

    commercial = login("commercial@clinique-esthetique.tn", os.environ["QA_COMMERCIAL_PASSWORD"])
    results.append(check("commercial_read_only_create_patient_rejected", commercial.post(f"{BASE}/patients", json={"nom": "Intrusion", "prenom": "Buyer", "telephone": "+21655000777"}, timeout=20), 403))

    public = requests.get("http://127.0.0.1:8180/api/public/praticiens", timeout=20)
    results.append(check("public_endpoint_anonymous_allowed", public, 200))

    report = {"checks": results, "passed": sum(1 for item in results if item["ok"]), "failed": sum(1 for item in results if not item["ok"])}
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))
    return 0 if report["failed"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
