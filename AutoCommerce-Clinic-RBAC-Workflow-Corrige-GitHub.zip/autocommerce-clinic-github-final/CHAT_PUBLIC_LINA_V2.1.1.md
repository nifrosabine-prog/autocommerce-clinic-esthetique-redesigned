# Chat public Lina — V2.1.1

Cette version rend Lina plus naturelle et plus utile tout en conservant un fonctionnement déterministe, sans LLM libre et sans accès aux données personnelles des patients.

| Amélioration | Implantation |
|---|---|
| Intentions enrichies | Horaires, samedi/dimanche, adresse, contact, WhatsApp, actes, prix, réservation et variantes françaises, anglaises et darija. |
| Réponses naturelles | Plusieurs formulations déterministes, avec orientation vers le formulaire de réservation. |
| Multilingue | Détection simple français / anglais / arabe et réponse dans la langue détectée. |
| Sécurité | Rate limiting 10/minute, message limité à 2 000 caractères, anti-injection, détresse prioritaire et journalisation serveur des cas sensibles. |
| Données personnelles | Aucun prochain rendez-vous ni dossier patient dans le chat public ; une identification dédiée reste une évolution séparée. |
| Expérience | Historique court du widget, indicateur d’écriture, lien de réservation et bouton WhatsApp toujours visible. |

Les demandes médicales, les tentatives de contournement et les demandes inconnues ne sont pas traitées par un modèle libre. Lina indique ses limites et oriente vers la clinique sans insister.

## Contrôle de mise en production

Le tenant public doit être configuré par `PUBLIC_CLINIC_ID`, et `PUBLIC_ROUTES_ENABLED` doit être activé explicitement. Le contenu dynamique des horaires, de l’adresse, du téléphone et des actes provient du branding public. Le bouton WhatsApp doit être vérifié avant mise en ligne.
