# Chat public Lina — V2.1

## Fonctionnement

Le landing page affiche un widget **« Lina — Assistante MBA Clinic »** en bas à droite ainsi qu’un bouton WhatsApp de secours. Le widget envoie les questions à `POST /api/public/chat` et reçoit une réponse JSON avec `reponse`, `statut` et `escalade`.

Le endpoint est monté sous `/api/public/chat` et `/api/v1/public/chat` pour compatibilité. Il applique un rate limiting de 10 requêtes par minute, limite le message à 2 000 caractères, vérifie la configuration du tenant public et ne reçoit ni token d’authentification ni identifiant de patient.

## Périmètre public

Le chat répond automatiquement aux demandes générales sur les horaires, l’adresse, les contacts, les actes publiés et la réservation. Il ne donne pas accès au prochain rendez-vous personnel depuis le chat public. Une identification légère et contrôlée devra être ajoutée dans une évolution séparée, sans demander de données médicales dans le widget public.

Les demandes médicales ou de détresse déclenchent une réponse d’urgence et une orientation humaine. Les tentatives d’injection sont refusées. Une question inconnue reçoit une réponse d’orientation vers les fonctions prises en charge, sans invention.

## Configuration

Le chat dépend de `PUBLIC_ROUTES_ENABLED`, `PUBLIC_CLINIC_ID` et du contenu public de branding. En production, les routes publiques restent désactivées tant que leur activation n’a pas été validée. Le numéro du bouton WhatsApp provient du branding public ; à défaut, la valeur de démonstration existante du landing est utilisée et doit être remplacée avant go-live.

## Fichiers concernés

| Élément | Fichier |
|---|---|
| Endpoint | `api-server/api/v1/public_chat.py` |
| Montage API | `api-server/api/v1/__init__.py` |
| Appel frontend | `autocommerce-app/client/src/lib/api.ts` |
| Widget | `autocommerce-app/client/src/components/public/LinaChatWidget.tsx` |
| Landing | `autocommerce-app/client/src/pages/public/LandingPage.tsx` |

## Références internes

[1]: ./LIMITES_ASSISTANT_IA.md "Limites de Lina"
[2]: ./GO_LIVE_CHECKLIST.md "Checklist go-live"

## Références

[1]: ./LIMITES_ASSISTANT_IA.md "Limites de Lina"
[2]: ./GO_LIVE_CHECKLIST.md "Checklist go-live"
