# MBA Clinic — Remise client V2.1 améliorée

## Objet de la remise

Cette livraison correspond à **AutoCommerce Clinic Enterprise — Bloc Esthétique 1, version V2.1 améliorée**, pour MBA Clinic à Tunis. Le périmètre est strictement **mono-clinique / mono-VPS**. L’archive contient le code, les configurations d’exemple, les scripts d’exploitation et la documentation nécessaires à une installation contrôlée.

Lina fonctionne principalement selon un moteur déterministe de règles et de données applicatives. Les questions informatives autorisées peuvent recevoir une réponse automatique lorsqu’une donnée fiable est disponible. Les actions d’écriture et les envois sortants restent soumis à confirmation ou validation humaine selon leur niveau de sensibilité.

## Périmètre inclus

| Domaine | Niveau V2.1 | Description de remise |
|---|---|---|
| Landing et réservation publique | Prêt | Parcours public inclus, activable explicitement. |
| Agenda / planning | Prêt | Gestion des rendez-vous et vues opérationnelles. |
| Patients | Prêt | Gestion cloisonnée par clinique et permissions. |
| Stock injectables et consommables | Prêt | Suivi opérationnel et alertes de stock. |
| Facturation | Correct | Totaux en `Decimal`, contrôles de lignes, statuts et transitions renforcés. |
| Équipe / RH | Correct | RBAC et opérations de compte encadrées par les routes existantes. |
| Workflows / automatisations | Correct | Les actions sensibles sont préparées puis validées. |
| Lina et omnicanal | Correct | Réponses informatives déterministes, escalade médicale et protection webhook. |
| Délégués, laboratoires, commissions, messages équipe, recrutement | Correct | Inclus selon les fonctionnalités présentes dans l’archive. |
| Téléconsultation | Partiel | Aucun engagement de téléconsultation complète. |
| Reporting avancé | Partiel | Les tableaux avancés ne constituent pas un engagement de BI complète. |

## Exclusions explicites

Le multi-clinique, le multi-VPS, la haute disponibilité, la téléconsultation complète, le diagnostic médical, le dosage, la posologie, l’interprétation de résultats, ainsi que tout LLM libre sur des conversations patients sont **hors périmètre**. Cette livraison ne contient ni secret de production ni donnée réelle de patient.

## Conditions de go-live

Le client doit fournir un serveur mono-VPS durci, une base de données et Redis correctement configurés, les clés de chiffrement distinctes, le domaine autorisé, les comptes Meta nécessaires et les secrets de webhook. `LLM_ENABLED=false`, `MEDICAL_AI_PROVIDER_APPROVED=false`, `WHATSAPP_ENABLED=false` et `WEBHOOKS_ENABLED=false` doivent rester les valeurs initiales jusqu’à validation de la checklist de mise en production.

Aucune activation de WhatsApp ne doit être réalisée sans concordance entre `CLINIC_ID`, `PUBLIC_CLINIC_ID` et `SOCIAL_WEBHOOK_CLINIC_ID`, vérification de signature et test en environnement de staging. Les campagnes et messages proactifs doivent rester bloqués tant qu’une approbation humaine et un mode d’exécution explicitement autorisé ne sont pas établis.

## Parcours de facturation remis

Une facture est créée en brouillon à partir d’un patient et, lorsque disponible, d’un dossier médical. Les montants sont calculés avec `Decimal`. Une ligne négative, une quantité nulle, une remise hors intervalle ou un taux de TVA invalide est refusé. Le paiement accepte uniquement les statuts et modes documentés ; une facture payée ne peut pas être annulée directement et doit suivre un parcours d’avoir.

## Support et responsabilité

La clinique reste responsable des secrets, des comptes tiers, des données introduites, de la validation des règles métier et de l’approbation des actions sensibles. La documentation de cette archive décrit les garde-fous techniques ; elle ne remplace pas les procédures internes, la validation réglementaire ou les consignes d’urgence de la clinique.

## Références internes

Consulter `GO_LIVE_CHECKLIST.md`, `READY_TO_GO_CERTIFICATION.md`, `LIMITES_ASSISTANT_IA.md`, `PERIMETRE_MODULES.md` et `V21_RELEASE_MANIFEST.md` avant toute activation en production.

*Document préparé par Manus AI — version V2.1.*

## Références

[1]: ./GO_LIVE_CHECKLIST.md "Checklist de mise en production"
[2]: ./LIMITES_ASSISTANT_IA.md "Limites de l’assistant IA"
[3]: ./PERIMETRE_MODULES.md "Périmètre des modules"
> Les références ci-dessus sont des documents internes livrés avec cette archive.
