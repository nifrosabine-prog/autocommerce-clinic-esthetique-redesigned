# Rapport de recette production — scénario patient clinique

## Environnement

La recette a été exécutée sur une base PostgreSQL 16 isolée `clinic_recette`, avec Redis 7 local, migrations Alembic appliquées jusqu’à `20260909_dossier_episode_link`, dépendances Python installées dans l’environnement virtuel et frontend servi depuis le build Vite de production sur le port 4173. Le backend FastAPI a été lancé sur le port 8000 avec `ENV=production`, `DEPLOYMENT_MODE=internal_single_clinic`, secrets locaux éphémères et comptes de recette non réels.

## Parcours exécuté

Le patient de recette a été créé une seule fois. L’assistante a ouvert le rendez-vous BBL dans l’agenda, marqué le patient comme arrivé, confirmé sa présence et enregistré l’accord d’examen. Ces trois transitions ont retourné HTTP 200 et ont ouvert l’épisode 1.

L’assistante a ensuite rempli le dossier d’accueil avec les attentes et les informations préparatoires. Le dossier a été enregistré avec `statut_clinique=brouillon`, sans contourner le consentement médical. Le dossier est explicitement rattaché à `episode_id=1` et au rendez-vous d’origine. Le médecin a retrouvé la même timeline du patient avec HTTP 200.

Le médecin a créé une intervention BBL dans le même épisode, a proposé l’acte BBL et a validé l’acte médical. L’assistante a ensuite validé l’acte financièrement. Un devis BBL de 2 500 DT a été créé, envoyé et accepté. Il a été converti en facture unique ; la TVA de 19 % a été calculée à 475 DT, pour un total TTC de 2 975 DT. Le paiement complet par carte a été accepté et le démarrage de l’intervention a retourné HTTP 200.

## Vérification du dossier unique

Après nettoyage des données techniques de test intermédiaires, les cardinalités finales sont les suivantes :

| Élément | Nombre | Identifiant ou état |
| --- | ---: | --- |
| Patient | 1 | Patient 1 |
| Rendez-vous | 1 | RDV 1, statut `accord` |
| Épisode | 1 | Épisode 1, statut `ouvert` |
| Dossier médical | 1 | Dossier 1, `episode_id=1`, brouillon |
| Intervention | 1 | Intervention BBL 2, `en_cours` |
| Devis | 1 | Devis BBL 2, accepté |
| Facture | 1 | Facture 2, payée |
| Paiement | 1 | Paiement complet, carte |

Le principe métier demandé est donc confirmé : **le patient ne change pas de dossier entre l’accueil et le médecin ; les éléments sont regroupés dans un épisode clinique unique**.

## Contrôles techniques

Les endpoints `/health` et `/ready` répondent correctement. Les connexions admin, assistante et médecin ont été testées. Le workspace protégé est accessible selon le rôle. Le frontend `/login`, `/dashboard`, `/workspace` et `/invoices` a été ouvert dans le navigateur de recette. Le build TypeScript/Vite et les 85 tests backend ciblés passent.

## Conformité front-end au plan

La navigation clinique est cohérente pour les blocs précédents : connexion, dashboard, workspace, agenda, accueil, patients, factures et stocks sont présents. Le workspace affiche bien les prochaines actions et `/invoices` affiche la facture payée avec les montants corrigés.

Un écart reste à traiter avant de considérer le plan entièrement réalisé côté frontend : les nouveaux endpoints spécialisés de devis, acceptation, conversion et paiement ont été testés avec succès par API, mais l’interface ne présente pas encore un écran complet de création et de suivi du devis BBL. La page Factures affiche la facture ; elle ne matérialise pas encore tout le workflow devis → acceptation → conversion → paiement. De même, la page d’accueil publique affiche actuellement que le module de réservation est temporairement indisponible dans cette recette.

La conclusion est donc : **le cœur métier backend et le parcours dossier unique sont validés ; le front-end est partiellement conforme et nécessite un écran devis/paiement relié aux nouvelles routes ainsi que la réactivation du module de réservation public avant production réelle**.

## Test complémentaire — injection médecin et dossier patient

Le médecin a enregistré une injection BBL de 2,5 ml depuis l’intervention 2, avec le produit « Acide hyaluronique BBL recette » et le lot `BBL-LOT-RECETTE-001`. L’enregistrement a retourné HTTP 200.

L’utilisation injectable est désormais liée simultanément à `patient_id=1`, `dossier_id=1`, `episode_id=1` et `intervention_id=2`. Le stock du lot est passé de 20 ml à 17,5 ml. La timeline du dossier médical affiche le produit, le lot et la quantité. La route de traçabilité `/api/v1/injectables/tracabilite/1` retourne également le produit, le fabricant, le lot, la quantité, le médecin et les notes.

Le correctif ajoute les champs `episode_id` et `intervention_id` à la requête d’utilisation injectable et les transmet au modèle `UtilisationLot`. Des contrôles empêchent désormais de rattacher une injection à un épisode ou à une intervention qui ne correspondent pas au dossier, à la clinique ou au praticien.

Les tests spécialisés stock/injections passent : **20 tests réussis**. Le build TypeScript/Vite reste réussi.

## Test complémentaire — deuxième injection et suivi automatique

Le médecin a créé un suivi `deuxieme_injection` rattaché au patient 1, au dossier 1, à l’épisode 1 et à l’intervention BBL 2. Le suivi reste d’abord à l’état `a_faire` et ne crée aucun rendez-vous automatiquement sans confirmation de la patiente.

Une tentative de création avec `patient_confirme=false` a été refusée par HTTP 409. Après confirmation explicite de la disponibilité de la patiente, le système a vérifié le créneau du médecin, la durée de l’acte et l’absence de conflit pour la patiente, puis a créé automatiquement le rendez-vous 3 le 15/09/2026 à 10:00, jusqu’à 12:00. Le suivi est passé à `en_cours` et conserve `rdv_id=3`.

Le front-end du cockpit clinique affiche désormais le bouton « Confirmer avec la patiente » pour un suivi lié à une intervention mais sans rendez-vous. L’action demande le créneau convenu, transmet la confirmation explicite et rafraîchit le suivi après création du rendez-vous.

Les tests ciblés opérations cliniques et épisode passent : **18 tests réussis**. Le build TypeScript/Vite reste réussi. La migration active est `20260909_suivi_rdv_link`.
