import os
import sys
import requests

BASE = os.environ.get("PUBLIC_BASE", "http://127.0.0.1:18000").rstrip("/")
PREFIX = "/api" if os.environ.get("PUBLIC_PROXY", "0") == "1" else ""
USERS = [
    ("directrice", "admin@clinic.local", "QA-Directrice-2026!"),
    ("medecin", "medecin@clinic.local", "QA-Medecin-2026!"),
    ("assistante", "assistante@clinic.local", "QA-Assistante-2026!"),
    ("commercial", "commercial@clinic.local", "QA-Commercial-2026!"),
    ("estheticienne", "estheticienne@clinic.local", "QA-Estheticienne-2026!"),
]

def check(response, expected, label):
    if response.status_code != expected:
        raise AssertionError(f"{label}: attendu {expected}, obtenu {response.status_code}: {response.text[:200]}")

def main():
    if PREFIX:
        health = requests.get("https://18000-iy8oy7whdeuec1nysdxnd-bf1f158d.us4.manus.computer/health", timeout=15)
        ready = requests.get("https://18000-iy8oy7whdeuec1nysdxnd-bf1f158d.us4.manus.computer/ready", timeout=15)
    else:
        health = requests.get(f"{BASE}/health", timeout=15)
        ready = requests.get(f"{BASE}/ready", timeout=15)
    check(health, 200, "health public")
    check(ready, 200, "ready public")
    tokens = {}
    for role, email, password in USERS:
        login = requests.post(f"{BASE}{PREFIX}/v1/auth/login", json={"identifier": email, "password": password}, timeout=15)
        check(login, 200, f"login {role} public")
        tokens[role] = login.json()["access_token"]
        me = requests.get(f"{BASE}{PREFIX}/v1/auth/me", headers={"Authorization": f"Bearer {tokens[role]}"}, timeout=15)
        check(me, 200, f"me {role} public")
        assert me.json()["role"] == role
    headers = {"Authorization": f"Bearer {tokens['directrice']}"}
    check(requests.get(f"{BASE}{PREFIX}/v1/users", headers=headers, timeout=15), 200, "directrice users public")
    for role in ("medecin", "assistante", "commercial", "estheticienne"):
        headers = {"Authorization": f"Bearer {tokens[role]}"}
        check(requests.get(f"{BASE}{PREFIX}/v1/users", headers=headers, timeout=15), 403, f"RBAC users {role} public")
    print("online_roles=OK")

if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ONLINE_ROLE_TEST_FAILED: {exc}", file=sys.stderr)
        raise
