# Modifications — suppression et export CSV

## Fonctionnalités ajoutées

La page **Gestion de l’Équipe** dispose maintenant d’un bouton **Exporter CSV**. L’export inclut les membres de la clinique courante, leurs informations professionnelles et leur statut. La suppression d’un membre reste protégée par une confirmation et le compte connecté ne peut pas se supprimer lui-même.

La page **Patients** dispose maintenant d’un bouton **Exporter CSV**. L’export peut reprendre la recherche actuellement saisie et ne contient que les patients visibles par l’utilisateur dans sa clinique. Les données médicales chiffrées et les patients déjà anonymisés sont exclus de cet export.

L’action patient est présentée comme **Supprimer**. Elle applique le droit à l’oubli RGPD existant : confirmation obligatoire, anonymisation irréversible et retrait de la liste active. Elle reste réservée aux rôles `directrice` et `admin`.

## Routes API

| Fonction | Route | Accès |
|---|---|---|
| Export équipe | `GET /api/private/users/export.csv` | `directrice`, `admin` |
| Export patients | `GET /api/private/patients/export.csv` | rôles autorisés à consulter les patients |
| Suppression équipe | `DELETE /api/private/users/{id}` | `directrice`, `admin` |
| Anonymisation patient | `DELETE /api/private/patients/{id}/rgpd` | `directrice`, `admin` |

Les CSV sont générés en UTF-8 avec BOM et retours à la ligne compatibles avec Excel. Les contrôles de périmètre par clinique et les restrictions RBAC sont effectués côté serveur.

## Vérifications effectuées

- Typecheck frontend : `pnpm check`
- Tests frontend : 69 tests passés
- Build frontend : `pnpm build`
- Compilation Python : `python3 -m compileall -q api-server`
- Tests backend ciblés : 28 tests passés
- Lint backend ciblé : `ruff check api/v1/users.py api/v1/patients.py`
