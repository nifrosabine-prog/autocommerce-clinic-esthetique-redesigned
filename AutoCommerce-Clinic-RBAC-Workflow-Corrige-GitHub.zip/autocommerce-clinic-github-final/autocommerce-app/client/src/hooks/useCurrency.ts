import { useEffect, useState } from 'react';
import { api } from '@/lib/api';

export interface ClinicCurrency {
  currency_code: string;
  currency_symbol: string;
}

const DEFAULT_CURRENCY: ClinicCurrency = { currency_code: 'TND', currency_symbol: 'DT' };

export function useCurrency(): ClinicCurrency {
  const [currency, setCurrency] = useState<ClinicCurrency>(DEFAULT_CURRENCY);

  useEffect(() => {
    let active = true;
    api.get('/settings/currency')
      .then((response) => {
        const code = String(response.data?.currency_code || DEFAULT_CURRENCY.currency_code).trim().toUpperCase();
        const symbol = String(response.data?.currency_symbol || DEFAULT_CURRENCY.currency_symbol).trim();
        if (active && code.length === 3 && symbol.length > 0) setCurrency({ currency_code: code, currency_symbol: symbol });
      })
      .catch(() => {
        // Le fallback local est volontairement silencieux pour ne pas masquer les données métier.
      });
    return () => { active = false; };
  }, []);

  return currency;
}
