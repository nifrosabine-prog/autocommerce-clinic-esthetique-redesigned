import asyncio
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / 'api-server'))

from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from middleware.auth import get_password_hash
from models.database import ActeMedical, Patient, ProduitInjectable, RoleEnum, Utilisateur, UtilisateurActe


async def main() -> None:
    engine = create_async_engine(os.environ['DATABASE_URL'])
    Session = async_sessionmaker(engine, expire_on_commit=False)
    admin_password = os.environ['E2E_ADMIN_PASSWORD']
    clinic_b_password = os.environ['E2E_CLINIC_B_PASSWORD']
    async with Session.begin() as db:
        admin = await db.scalar(select(Utilisateur).where(Utilisateur.email == os.environ['E2E_ADMIN_EMAIL']))
        if admin is None:
            admin = Utilisateur(
                clinic_id=1,
                email=os.environ['E2E_ADMIN_EMAIL'],
                hashed_password=get_password_hash(admin_password),
                nom='Admin',
                prenom='Clinic A',
                role=RoleEnum.DIRECTRICE.value,
                is_active=True,
            )
            db.add(admin)
            await db.flush()
        else:
            admin.clinic_id = 1
            admin.role = RoleEnum.DIRECTRICE.value
            admin.is_active = True

        clinic_b = await db.scalar(select(Utilisateur).where(Utilisateur.email == os.environ['E2E_CLINIC_B_EMAIL']))
        if clinic_b is None:
            clinic_b = Utilisateur(
                clinic_id=2,
                email=os.environ['E2E_CLINIC_B_EMAIL'],
                hashed_password=get_password_hash(clinic_b_password),
                nom='Admin',
                prenom='Clinic B',
                role=RoleEnum.DIRECTRICE.value,
                is_active=True,
            )
            db.add(clinic_b)
            await db.flush()
        else:
            clinic_b.clinic_id = 2
            clinic_b.role = RoleEnum.DIRECTRICE.value
            clinic_b.is_active = True
            clinic_b.hashed_password = get_password_hash(clinic_b_password)

        practitioner = await db.scalar(select(Utilisateur).where(Utilisateur.email == 'doctor@clinic-a.local'))
        if practitioner is None:
            practitioner = Utilisateur(
                clinic_id=1,
                email='doctor@clinic-a.local',
                hashed_password=get_password_hash(admin_password),
                nom='Martin',
                prenom='Ada',
                role=RoleEnum.MEDECIN.value,
                specialite='Médecine esthétique',
                is_active=True,
            )
            db.add(practitioner)
            await db.flush()

        acte = await db.scalar(select(ActeMedical).where(ActeMedical.clinic_id == 1, ActeMedical.nom == 'Consultation esthétique'))
        if acte is None:
            acte = ActeMedical(
                clinic_id=1,
                nom='Consultation esthétique',
                nom_normalise='consultation esthétique',
                categorie='consultation',
                duree_minutes=45,
                prix_base=150,
                is_gratuit=False,
                description='Évaluation initiale',
                is_active=True,
                is_public=False,
            )
            db.add(acte)
            await db.flush()
            # Colonnes ajoutées par la migration catalogue, absentes du modèle ORM historique.
            await db.execute(text("""
                UPDATE actes_medicaux
                SET nom_normalise = lower(trim(nom)), is_gratuit = false, is_public = false
                WHERE id = :acte_id
            """), {"acte_id": acte.id})

        product = await db.scalar(select(ProduitInjectable).where(
            ProduitInjectable.clinic_id == 1,
            ProduitInjectable.nom == 'Produit QA synthétique',
        ))
        if product is None:
            db.add(ProduitInjectable(
                clinic_id=1,
                nom='Produit QA synthétique',
                fabricant='QA',
                categorie='test',
                unite='ml',
                prix_achat=1,
                prix_vente=2,
                stock_actuel=0,
                stock_minimum=0,
                stock_alerte=0,
                is_active=True,
            ))

        link = await db.scalar(select(UtilisateurActe).where(
            UtilisateurActe.utilisateur_id == practitioner.id,
            UtilisateurActe.acte_id == acte.id,
        ))
        if link is None:
            db.add(UtilisateurActe(utilisateur_id=practitioner.id, acte_id=acte.id))

        patient_a = await db.scalar(select(Patient).where(Patient.telephone == '+21620000001'))
        if patient_a is None:
            db.add(Patient(
                clinic_id=1,
                nom='Patient',
                prenom='Clinic A',
                telephone='+21620000001',
                email='patient-a@example.com',
                is_active=True,
            ))

        patient_b = await db.scalar(select(Patient).where(Patient.telephone == '+21620000002'))
        if patient_b is None:
            db.add(Patient(
                clinic_id=2,
                nom='Patient',
                prenom='Clinic B',
                telephone='+21620000002',
                email='patient-b@example.com',
                whatsapp_phone='+21629999999',
                is_active=True,
            ))
    await engine.dispose()
    print('QA_SEED_PASS')


if __name__ == '__main__':
    asyncio.run(main())
