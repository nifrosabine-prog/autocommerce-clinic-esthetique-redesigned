# Rollback — mono-VPS clinique

Le rollback n’est acceptable que s’il est documenté, testé et compatible avec l’état réel de la base.

## Pré-conditions

- sauvegarde fraîche prise avant action ;
- version source et version cible identifiées ;
- décision tracée ;
- procédure Alembic de retour connue et testée ;
- fenêtre de maintenance approuvée.

## Procédure minimale

1. figer les écritures ;
2. conserver logs et identifiants de corrélation ;
3. redéployer l’image précédente ;
4. appliquer uniquement la procédure base compatible avec cette image ;
5. exécuter `/health`, `/ready`, login, MFA, refresh, logout, booking public et contrôle worker/beat ;
6. archiver la preuve de retour arrière.

## Interdiction

Ne jamais lancer un downgrade Alembic non testé directement sur la base active d’une clinique.
