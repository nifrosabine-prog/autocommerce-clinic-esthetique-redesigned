# Installation — mono-VPS clinique

Cette archive doit être installée comme **une instance dédiée à une clinique**. Le chemin recommandé pour les secrets est `/etc/autocommerce/.env.production` et le chemin recommandé pour les données applicatives est `/var/lib/autocommerce`.

## Prérequis

- Docker Engine + Compose v2
- Nginx sur le VPS cible
- firewall actif
- volume persistant pour les données
- support de sauvegarde sur device distinct du disque système
- certificats TLS et DNS réels avant ouverture au public

## Configuration minimale

Utiliser exclusivement `.env.production.example` comme contrat. Le fichier d’environnement réel doit être hors dépôt et protégé en `0600`.

En production mono-VPS :

- `ENV=production`
- `DEPLOYMENT_MODE=internal_single_clinic`
- `CLINIC_ID` positif et unique
- `PUBLIC_CLINIC_ID=CLINIC_ID` si booking public activé
- `SOCIAL_WEBHOOK_CLINIC_ID=CLINIC_ID` si webhooks activés
- `REFRESH_COOKIE_SECURE=true`
- `CORS_ORIGINS` strict et sans wildcard

## Démarrage

```bash
API_ENV_FILE=/etc/autocommerce/.env.production ./scripts/verify_infrastructure.sh
DEPLOY_ENV_FILE=/etc/autocommerce/.env.production ./scripts/first_deploy.sh
```

Le compte administrateur initial doit être injecté hors dépôt avec `ADMIN_EMAIL` et `ADMIN_PASSWORD`.

## Première validation obligatoire

Après démarrage, exécuter successivement :

- `/health`
- `/ready`
- login
- MFA
- refresh
- logout
- booking public puis validation privée
- contrôle RBAC par rôle
- contrôle d’isolation clinique
- exécution worker/beat
- sauvegarde puis restauration isolée

Sans ces preuves sur le VPS cible, la release reste au statut **prête pour go-live contrôlé**, pas **production ready**.
