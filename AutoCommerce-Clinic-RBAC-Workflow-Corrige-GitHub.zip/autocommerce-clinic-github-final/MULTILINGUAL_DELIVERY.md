# Livraison multilingue — MBA Clinic

La landing page prend désormais en charge le français, l’anglais, l’italien, l’allemand et l’arabe. La seconde partie de la page, notamment « Qui sommes-nous », « Nos actes », les cartes de soins, les détails affichés par « Découvrir », le rappel, le contact et le footer, utilise des contenus localisés.

Les actes disposent de titres, descriptions, bénéfices et boutons traduits dans les cinq langues. Les libellés du formulaire de réservation et du formulaire de rappel ont également été localisés. L’arabe active automatiquement `lang="ar"` et `dir="rtl"` sur le document.

| Vérification | Résultat |
|---|---|
| TypeScript | Réussi |
| Build frontend | Réussi |
| PostgreSQL / Redis | Prêts |
| API `/health` | OK |
| API `/ready` | OK — PostgreSQL et Redis |
| Français | Vérifié |
| Anglais | Vérifié |
| Italien | Ressources et landing localisées |
| Allemand | Ressources et landing localisées |
| Arabe | Ressources, landing et RTL localisés |

Les secrets d’environnement et dépendances installées localement sont volontairement exclus de l’archive ZIP. Le fichier `package.json` et le lockfile permettent de réinstaller les dépendances avec `pnpm install --frozen-lockfile`.
