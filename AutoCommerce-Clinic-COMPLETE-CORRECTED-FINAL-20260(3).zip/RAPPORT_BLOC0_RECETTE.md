# Rapport Bloc 0 — État de référence et recette isolée

**Projet audité :** `AutoCommerce-Clinic-BLOCS0-10-recette-scenario-fin(4).zip`  
**Répertoire de recette :** `/home/ubuntu/clinic-audit/bloc1_extract`  
**Date de l’audit :** 10 septembre 2026  
**Périmètre :** audit statique, installation des dépendances, PostgreSQL, Redis, migrations, tests backend, contrôle TypeScript, tests frontend et build Vite.

## 1. Environnement de recette

L’audit a été réalisé dans une recette locale isolée. Aucune base de production et aucun fichier de production n’ont été utilisés.

| Élément | Résultat |
|---|---|
| Système | Ubuntu 24.04 |
| Python | 3.12.3 |
| Node.js | v22.13.0 |
| pnpm | 11.24.0 au niveau système ; package projet installé via lockfile |
| PostgreSQL | 16.15 |
| Redis | 7.0.15 |
| esbuild | 0.25.12, installé par les dépendances frontend |
| Base de recette | `clinic_test` |
| Redis de recette | base logique 15 |
| PostgreSQL final | migration `20260909_suivi_rdv_link` |
| Redis | `PONG` obtenu |

La base et Redis sont des services de recette locaux. Ils ne constituent pas une preuve de disponibilité ou de configuration de la production réelle.

## 2. Structure inspectée

Le projet contient un backend FastAPI avec modèles SQLAlchemy, migrations Alembic, services, routeurs et tests. Le frontend utilise React, Vite et TypeScript.

Éléments importants confirmés :

- `api-server/models/episode_core.py` existe ;
- `api-server/models/__init__.py` importe `episode_core` ;
- `api-server/alembic/env.py` importe `episode_core` ;
- `api-server/tests/test_episode_core_bloc1.py` existe ;
- `autocommerce-app/client/src` existe ;
- 87 fichiers de tests backend ont été trouvés ;
- 15 fichiers de tests frontend/E2E ont été trouvés ;
- les configurations pytest, Vitest et Playwright sont présentes.

## 3. Migrations Alembic

L’analyse statique a identifié **53 révisions**, sans parent manquant et avec une seule tête :

```text
20260909_suivi_rdv_link
```

Les opérations suivantes ont été exécutées sur PostgreSQL :

```text
alembic upgrade head
alembic downgrade -1
alembic upgrade head
alembic downgrade -4
alembic upgrade head
alembic current
alembic heads
```

**Résultat :** toutes les opérations ont réussi. La base est revenue à la tête `20260909_suivi_rdv_link`.

Cela valide la chaîne de migrations dans cette base vide de recette. Il reste à effectuer une validation complémentaire avec des données représentatives avant de conclure sur la compatibilité de toutes les anciennes données.

## 4. Résultats des validations réellement exécutées

### Backend

- compilation Python : réussie ;
- tests pytest : **697 réussis, 1 ignoré** ;
- code retour pytest : 0 ;
- connexion PostgreSQL : réussie ;
- migrations Alembic : réussies ;
- connexion Redis : réussie.

### Frontend

- contrôle TypeScript `pnpm check` : réussi ;
- tests Vitest : **13 fichiers réussis, 73 tests réussis** ;
- build Vite : réussi ;
- esbuild : fonctionnel ;
- taille notable de certains bundles : `StockPage` environ 472 kB et bundle principal environ 405 kB avant gzip. Ce n’est pas bloquant pour le Bloc 0, mais cela mérite une optimisation ultérieure.

## 5. Écarts et risques identifiés

La réussite technique des tests ne signifie pas que tout le parcours clinique demandé est complet. Le rapport Bloc 1 déjà présent dans l’archive identifie notamment les points suivants à confirmer ou finaliser :

1. rattachement cohérent et obligatoire lorsque nécessaire des photos, consentements, simulations IA, utilisations de lots et suivis post-acte à `EpisodePatient` et `Intervention` ;
2. décision cible entre `ActeCatalogue` et `ActeMedical` ;
3. clarification entre `SuiviPostSeance` et `SuiviPostActe` ;
4. tests explicites d’isolation clinique et d’isolation épisode/intervention pour les objets cliniques historiques ;
5. validation des contraintes PostgreSQL avec des données et des cas d’erreur réalistes ;
6. vérification de la compatibilité des migrations additives avec une base contenant des données existantes ;
7. revue fonctionnelle du parcours frontend complet, au-delà du build et des tests unitaires.

Le service systemd PostgreSQL apparaît comme `inactive` au niveau du wrapper dans cet environnement, alors que le cluster PostgreSQL est démarré et que les connexions et migrations ont réussi. Cette différence est propre à l’environnement sandbox et doit être vérifiée sur l’infrastructure cible.

## 6. Conclusion du Bloc 0

Le Bloc 0 peut être considéré comme **validé pour l’environnement de recette locale** : le projet a été inspecté sans modification du code source, l’environnement nécessaire a été installé, la chaîne Alembic a été exécutée sur PostgreSQL, Redis est joignable, les tests backend ont réussi et le frontend compile et passe ses tests.

Le projet est suffisamment stable pour commencer les corrections fonctionnelles. La prochaine priorité recommandée est le **Bloc 1**, avec une revue ciblée des rattachements cliniques et des tests de portée, avant toute extension importante du frontend.

## 7. Limites de ce rapport

Ce rapport ne prétend pas avoir validé :

- une vraie instance de production ;
- la configuration des secrets et services externes ;
- les connecteurs WhatsApp ou IA avec leurs comptes réels ;
- un parcours navigateur complet avec comptes de recette authentifiés ;
- la sécurité d’un déploiement public ;
- la migration d’une base de production existante.

Aucune de ces validations non exécutées n’est présentée comme réussie.
