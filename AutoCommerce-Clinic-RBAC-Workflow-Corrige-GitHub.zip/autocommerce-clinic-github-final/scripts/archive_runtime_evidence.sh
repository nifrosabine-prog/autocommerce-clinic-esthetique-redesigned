#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
COMPOSE_FILE="${COMPOSE_FILE:-docker-compose.mono-vps.yml}"
ENV_FILE="${DEPLOY_ENV_FILE:-/etc/autocommerce/.env.production}"
STAMP="$(date +%Y%m%d_%H%M%S)"
OUT_DIR="${OUT_DIR:-$ROOT_DIR/evidence/vps_target_${STAMP}}"
mkdir -p "$OUT_DIR"

{
  echo "timestamp=$STAMP"
  echo "compose_file=$COMPOSE_FILE"
  echo "env_file=$ENV_FILE"
  echo "hostname=$(hostname)"
  echo "docker_version=$(docker --version)"
} > "$OUT_DIR/context.txt"

docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" ps > "$OUT_DIR/docker_compose_ps.txt"
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" logs --tail=200 api > "$OUT_DIR/api_logs_tail.txt" || true
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" logs --tail=200 worker > "$OUT_DIR/worker_logs_tail.txt" || true
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" logs --tail=200 beat > "$OUT_DIR/beat_logs_tail.txt" || true
curl -fsS http://127.0.0.1:8000/health > "$OUT_DIR/health.json"
curl -fsS http://127.0.0.1:8000/ready > "$OUT_DIR/ready.json"
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T api alembic current > "$OUT_DIR/alembic_current.txt"
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T api alembic heads > "$OUT_DIR/alembic_heads.txt"

echo "Archive de preuves créée dans $OUT_DIR"
