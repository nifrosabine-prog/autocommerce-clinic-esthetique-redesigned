import React, { useEffect, useRef, useState } from 'react';
import { BrowserMultiFormatReader, IScannerControls } from '@zxing/browser';
import { NotFoundException } from '@zxing/library';
import { Button } from '@/components/ui/button';
import { Camera, CameraOff, AlertCircle } from 'lucide-react';

interface BarcodeCameraScannerProps {
  /** Appelé avec le texte décodé après validation explicite de l'utilisateur. */
  onDetected: (code: string) => void;
  /** Format d'affichage : plein cadre ou compact. */
  compact?: boolean;
}

/**
 * Scanner caméra réel — QR code et codes-barres (Code 128, EAN...).
 * Le résultat est présenté à l'utilisateur avant transmission au flux stock.
 */
export function BarcodeCameraScanner({ onDetected, compact = false }: BarcodeCameraScannerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const controlsRef = useRef<IScannerControls | null>(null);
  const readerRef = useRef<BrowserMultiFormatReader | null>(null);
  const lastCodeRef = useRef<{ code: string; at: number } | null>(null);

  const [isActive, setIsActive] = useState(false);
  const [isStarting, setIsStarting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pendingCode, setPendingCode] = useState<string | null>(null);
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [deviceId, setDeviceId] = useState<string | undefined>(undefined);

  useEffect(() => {
    return () => {
      controlsRef.current?.stop();
    };
  }, []);

  const listCameras = async () => {
    try {
      const cams = await BrowserMultiFormatReader.listVideoInputDevices();
      setDevices(cams);
      const back = cams.find((d) => /back|rear|environment/i.test(d.label));
      setDeviceId((back || cams[cams.length - 1])?.deviceId);
    } catch {
      // Certains navigateurs masquent les appareils avant l'autorisation caméra.
    }
  };

  useEffect(() => {
    listCameras();
  }, []);

  const start = async () => {
    setError(null);
    setPendingCode(null);
    setIsStarting(true);
    if (!readerRef.current) {
      readerRef.current = new BrowserMultiFormatReader();
    }

    try {
      const constraints: MediaStreamConstraints = deviceId
        ? { video: { deviceId: { exact: deviceId }, facingMode: { ideal: 'environment' } } }
        : { video: { facingMode: { ideal: 'environment' } } };
      const controls = await readerRef.current.decodeFromConstraints(
        constraints,
        videoRef.current!,
        (result, err) => {
          if (result) {
            const code = result.getText().trim();
            const now = Date.now();
            if (!code || (lastCodeRef.current?.code === code && now - lastCodeRef.current.at < 3000)) {
              return;
            }
            lastCodeRef.current = { code, at: now };
            controlsRef.current?.stop();
            controlsRef.current = null;
            setIsActive(false);
            setPendingCode(code);
          }
          if (err && !(err instanceof NotFoundException)) {
            console.error('Erreur de scan caméra:', err);
          }
        },
      );
      controlsRef.current = controls;
      setIsActive(true);
      // Certains navigateurs mobiles ne lancent pas automatiquement la vidéo
      // après l’autorisation caméra : forcer la lecture après le démarrage ZXing.
      await videoRef.current?.play().catch(() => undefined);
      await listCameras();
    } catch (e: any) {
      let message = 'Impossible d’accéder à la caméra.';
      if (e?.name === 'NotAllowedError') {
        message = 'Accès caméra refusé. Autorisez la caméra dans les paramètres du navigateur.';
      } else if (e?.name === 'NotFoundError') {
        message = 'Aucune caméra détectée sur cet appareil.';
      } else if (window.location.protocol !== 'https:' && window.location.hostname !== 'localhost') {
        message = 'Le scan caméra nécessite une connexion HTTPS.';
      }
      setError(message);
      setIsActive(false);
    } finally {
      setIsStarting(false);
    }
  };

  const stop = () => {
    controlsRef.current?.stop();
    controlsRef.current = null;
    setIsActive(false);
  };

  const validateDetectedCode = () => {
    if (!pendingCode) return;
    const code = pendingCode;
    setPendingCode(null);
    onDetected(code);
  };

  const toggle = () => {
    if (isActive) stop();
    else start();
  };

  return (
    <div className="space-y-2">
      <Button
        type="button"
        variant={isActive ? 'destructive' : 'default'}
        onClick={toggle}
        disabled={isStarting}
        className="w-full sm:w-auto"
      >
        {isActive ? <CameraOff className="w-4 h-4 mr-2" /> : <Camera className="w-4 h-4 mr-2" />}
        {isStarting ? 'Démarrage...' : isActive ? 'Arrêter la caméra' : 'Scanner avec la caméra'}
      </Button>

      {devices.length > 1 && isActive && (
        <select
          value={deviceId}
          onChange={(e) => { setDeviceId(e.target.value); stop(); }}
          className="w-full h-9 px-3 border rounded-md text-sm"
        >
          {devices.map((d) => (
            <option key={d.deviceId} value={d.deviceId}>{d.label || 'Caméra'}</option>
          ))}
        </select>
      )}

      {error && (
        <div className="flex items-start gap-2 text-sm text-destructive bg-destructive/10 rounded-md p-2">
          <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {pendingCode && (
        <div className="flex flex-col gap-2 rounded-md border border-primary/30 bg-primary/5 p-3 text-sm">
          <span className="font-medium break-all">Code détecté : {pendingCode}</span>
          <div className="flex flex-wrap gap-2">
            <Button type="button" onClick={validateDetectedCode}>Valider le code</Button>
            <Button type="button" variant="outline" onClick={start}>Scanner à nouveau</Button>
          </div>
        </div>
      )}

      <div
        className={`relative overflow-hidden rounded-md bg-black ${isActive ? '' : 'hidden'} ${compact ? 'aspect-video max-h-48' : 'aspect-video'}`}
      >
        <video ref={videoRef} className="w-full h-full object-cover" muted playsInline />
        {isActive && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-2/3 h-2/3 border-2 border-white/70 rounded-lg" />
          </div>
        )}
      </div>
    </div>
  );
}
