"""Catalogue public explicite et contraintes métier des actes.

Revision ID: 20260825_catalogue_public_actes
Revises: 20260822_mfa_secret_text
Create Date: 2026-08-25
"""

from alembic import op
import sqlalchemy as sa


revision = "20260825_catalogue_public_actes"
down_revision = "20260822_mfa_secret_text"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("utilisateurs", sa.Column("is_public", sa.Boolean(), nullable=False, server_default=sa.false()))
    op.add_column("actes_medicaux", sa.Column("nom_normalise", sa.String(length=200), nullable=True))
    op.add_column("actes_medicaux", sa.Column("is_gratuit", sa.Boolean(), nullable=False, server_default=sa.false()))
    op.add_column("actes_medicaux", sa.Column("is_public", sa.Boolean(), nullable=False, server_default=sa.false()))

    # Les entrées existantes non cohérentes sont retirées de l’offre active et
    # publique. Les doublons historiques sont archivés avec un nom technique
    # distinct afin que l’upgrade ne perde aucune ligne ni ne bloque sur la
    # contrainte d’unicité. Un prix nul n’est converti en gratuit que lorsque
    # le libellé ou la description l’indique explicitement ; les autres cas
    # restent archivés pour revue humaine.
    op.execute("""
        WITH ranked AS (
            SELECT
                id,
                clinic_id,
                lower(trim(nom)) AS normalized_base,
                CASE WHEN prix_base = 0 AND (
                    lower(nom) LIKE '%gratuit%'
                    OR lower(coalesce(description, '')) LIKE '%gratuit%'
                ) THEN true ELSE false END AS gratuit_explicit,
                row_number() OVER (
                    PARTITION BY clinic_id, lower(trim(nom))
                    ORDER BY is_active DESC, created_at DESC NULLS LAST, id DESC
                ) AS duplicate_rank
            FROM actes_medicaux
        )
        UPDATE actes_medicaux AS acte
        SET nom_normalise = CASE
                WHEN ranked.duplicate_rank = 1 THEN ranked.normalized_base
                ELSE left(ranked.normalized_base, 175) || '--archive-' || acte.id
            END,
            is_gratuit = ranked.gratuit_explicit,
            is_active = CASE
                WHEN ranked.duplicate_rank > 1
                  OR length(trim(acte.nom)) < 2
                  OR length(trim(acte.categorie)) < 2
                  OR acte.duree_minutes < 5
                  OR acte.duree_minutes > 480
                  OR acte.prix_base < 0
                  OR (acte.prix_base = 0 AND NOT ranked.gratuit_explicit)
                THEN false
                ELSE acte.is_active
            END,
            is_public = false
        FROM ranked
        WHERE acte.id = ranked.id
    """)
    op.alter_column("actes_medicaux", "nom_normalise", nullable=False)
    op.create_unique_constraint("uq_actes_clinic_nom_normalise", "actes_medicaux", ["clinic_id", "nom_normalise"])
    op.create_check_constraint("ck_actes_nom_non_vide", "actes_medicaux", "length(trim(nom)) >= 2")
    op.create_check_constraint("ck_actes_categorie_non_vide", "actes_medicaux", "length(trim(categorie)) >= 2")
    op.create_check_constraint("ck_actes_duree_bornee", "actes_medicaux", "duree_minutes BETWEEN 5 AND 480")
    op.create_check_constraint("ck_actes_prix_non_negatif", "actes_medicaux", "prix_base >= 0")
    op.create_check_constraint("ck_actes_prix_ou_gratuit", "actes_medicaux", "is_gratuit = true OR prix_base > 0")
    op.create_index("ix_actes_publics", "actes_medicaux", ["clinic_id", "is_active", "is_public"])


def downgrade() -> None:
    op.drop_index("ix_actes_publics", table_name="actes_medicaux")
    op.drop_constraint("ck_actes_prix_ou_gratuit", "actes_medicaux", type_="check")
    op.drop_constraint("ck_actes_prix_non_negatif", "actes_medicaux", type_="check")
    op.drop_constraint("ck_actes_duree_bornee", "actes_medicaux", type_="check")
    op.drop_constraint("ck_actes_categorie_non_vide", "actes_medicaux", type_="check")
    op.drop_constraint("ck_actes_nom_non_vide", "actes_medicaux", type_="check")
    op.drop_constraint("uq_actes_clinic_nom_normalise", "actes_medicaux", type_="unique")
    op.drop_column("actes_medicaux", "is_public")
    op.drop_column("actes_medicaux", "is_gratuit")
    op.drop_column("actes_medicaux", "nom_normalise")
    op.drop_column("utilisateurs", "is_public")
