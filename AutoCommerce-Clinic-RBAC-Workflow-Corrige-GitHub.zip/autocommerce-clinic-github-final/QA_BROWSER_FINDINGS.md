# Constats QA navigateur — Clinique Esthétique

Date de la validation : 26 août 2026.

Le lien temporaire local répond et affiche le titre « Clinique Esthétique ». La landing est identifiée « Médecine esthétique / AutoCommerce Clinic » et expose les parcours Réserver un rendez-vous, Être rappelé, sélection d’un praticien, sélection d’un acte et consentements. Les données visibles sont synthétiques : Ada Martin — Médecine esthétique et Consultation esthétique.

La page `/login` présente bien les champs Identifiant, Mot de passe et le bouton Se connecter. La connexion avec `admin.esthetique.qa@clinic.local` a abouti vers `/dashboard`.

Le tableau de bord connecté affiche `Clinic A Admin`, le rôle `directrice`, les accès Agenda, Patients, Factures, Stock et les modules Automatisations IA, Délégués & Labos et Factures & Dépenses. Les indicateurs sont à zéro, ce qui est cohérent avec une base de démonstration fraîche. Aucun libellé dentaire n’a été observé dans ces écrans.

## Parcours Patients

La page Patients affiche un patient synthétique et une barre `Rechercher par nom, prénom ou téléphone...`. La saisie `Clinic A` conserve le patient attendu dans la liste, confirmant le filtrage par nom/prénom. Les actions `Voir`, `Éditer` et `Anonymiser` sont présentes.

## Parcours Stock injectable

La page Gestion des Stocks affiche les onglets Injectables et Consommables, un produit synthétique `Produit QA synthétique — QA` et son état `RUPTURE`. Le bouton Ajouter un lot ouvre bien une boîte de dialogue. La liste Produit contient effectivement le produit synthétique et le bouton `Nouveau produit` est visible, ce qui corrige le défaut antérieur de liste vide/disparition du sélecteur.

Le lot synthétique `QA-LOT-001` a été enregistré avec succès : notification `Lot ajouté`, stock affiché à `5 ml`, `1` lot et statut `OK`. Le basculement vers Consommables fonctionne et affiche l’état vide explicite ainsi que le bouton `Nouveau consommable`.

## Parcours Facturation

La page Factures & Dépenses affiche un état vide lisible `Aucune facture`, sans JSON brut, et expose les onglets Factures clients, Actes à facturer, Dépenses & Achats et Audit Financier. Le bouton Nouvelle facture ouvre un formulaire fonctionnel. La recherche du patient synthétique `Clinic A` fait apparaître la suggestion `Clinic A Patient — +21620000001`.

La facture synthétique a été créée avec succès : notification `Facture créée`, numéro `F-2026-0001`, montant `178.5 DT`, statut lisible `Brouillon`, date d’émission et actions `Payer` / `Annuler`. Aucun JSON brut n’est affiché dans la table.

## Parcours Délégués & Labos

La page `/delegues` s’ouvre et le bouton `Nouvelle Visite` déclenche bien une boîte de dialogue contenant Délégué, Date et heure, Objet, Compte rendu et Enregistrer la visite. La base QA ne contient toutefois encore aucun délégué, donc le sélecteur reste sur `Sélectionner un délégué`; ce point doit être alimenté par un laboratoire/délégué synthétique avant de pouvoir valider l’enregistrement métier complet.

L’onglet Laboratoires Partenaires affiche le bouton `Ajouter Labo`, qui ouvre désormais un formulaire complet. Après saisie de valeurs synthétiques, l’enregistrement a abouti avec notification `Laboratoire ajouté`. Le retour automatique vers l’onglet Visites & Dotations est observé; le formulaire de visite est donc câblé, mais il faut recharger l’onglet pour confirmer que le nouveau délégué apparaît dans son sélecteur.

Après retour sur Visites & Dotations et réouverture de Nouvelle Visite, le sélecteur contient `Délégué Synthétique`. Le flux de création du laboratoire alimente donc correctement le flux de visite.

Le premier essai a révélé et confirmé un vrai bug de compatibilité timezone : le navigateur envoyait un datetime aware alors que PostgreSQL attendait un timestamp sans timezone. La route a été corrigée pour convertir en UTC naïf. Après redémarrage, le même formulaire s’enregistre avec notification `Visite enregistrée`, et l’historique affiche `26/08/2026 — Délégué Synthétique — Présentation produit injectable QA`.

## Parcours Automatisations IA

Le modèle `Rappel Anniversaire` a été créé en brouillon avec succès. Son exécution a abouti à `Workflow exécuté : une validation humaine est requise`, avec une exécution comptabilisée, `0` erreur et `1` approbation à valider. L’historique indique `draft_send_whatsapp — À approuver` et `add_fidelite_points — Terminé`. Aucun rollback SQL, aucune erreur de troncature et aucun HTTP 500 n’ont été observés. L’approbation WhatsApp n’a pas été déclenchée, car elle constitue une action externe nécessitant la validation humaine prévue par le workflow.

## Parcours Agenda

L’Agenda affiche Jour/Semaine, les demandes publiques à traiter et le bouton Nouveau RDV. Le formulaire accepte le patient `Clinic A Patient`, le praticien `Ada Martin` et l’acte `Consultation esthétique`. Après sélection de l’acte, les créneaux apparaissent réellement, de `09:00` à `17:00` par pas de 30 minutes. La configuration minimale praticien-acte est donc opérationnelle dans l’environnement QA.

Le créneau `09:00` a été sélectionné et le rendez-vous a été créé avec notification `Rendez-vous créé`. L’agenda affiche le patient, l’acte, le praticien et le statut `Planifié`. L’étiquette `Consentement manquant` est visible : c’est un garde-fou métier cohérent, pas une erreur technique, et elle empêche de considérer le rendez-vous comme prêt pour un acte sans consentement.

## Gestion Équipe et contrôle des routes

L’URL `/team` renvoie une page 404, mais elle n’est pas la route déclarée par l’application. Le lien de navigation pointe correctement vers `/admin/equipe`, qui se charge sans erreur et affiche le compte administratrice ainsi que le praticien Ada Martin. Ce contrôle ne révèle donc pas de bug de navigation produit; la route correcte est `/admin/equipe`.

## Gestion Équipe — création employé

Le formulaire Nouveau membre a accepté un compte assistante entièrement synthétique (`Sara Secrétaire QA`, `sara.qa@clinic.local`) et l’enregistrement a abouti avec notification `Compte créé`. Le nouveau compte apparaît actif dans la table. Le défaut de sauvegarde d’employé signalé précédemment n’est pas reproduit dans la version canonique.

## Parcours Réservation Publique (Landing)

Le bouton `Réserver` de la landing page a été testé avec succès. Après avoir renseigné le prénom, le nom, le téléphone, le praticien, l’acte et un créneau valide (sur une date future pour éviter les créneaux passés), le clic sur `Réserver` a déclenché la notification `Demande de rendez-vous reçue` et affiché le message de confirmation `Référence #1`. Le bouton n’est pas bloqué; il nécessite simplement que tous les champs obligatoires (y compris le créneau et le consentement) soient remplis pour s’activer.

## Validation End-to-End Réservation

La demande publique `Test Réservation QA` apparaît instantanément dans l’espace administratrice sous `Demandes publiques à traiter (1)`. Les boutons `Approuver` et `Rejeter` sont présents. Le workflow complet, de la landing page jusqu’au tableau de bord administratif, est donc **100% fonctionnel et sans blocage**.

## Validation Railway production — réservation publique

Après le déploiement `c9555eb`, le domaine `https://autocommerce-clinic-esthetique-redesigned-production.up.railway.app/` affiche bien `Clinique Esthétique`. Avec des données synthétiques (`QA Production`, `Landing Esthétique`, `+216 20000001`), le praticien `anis tety — BBL.LIFTINH`, l’acte `Bbl` et la date du jour sans créneau, la landing affiche automatiquement : `Aucun créneau restant aujourd’hui. Nous vous proposons le prochain jour ouvré.` Elle bascule au `27/08/2026` et propose les créneaux de `09:00` à `17:30`.

Le créneau `09:00` a été sélectionné, le consentement a été coché et la soumission publique a généré dans Railway un `POST /api/public/reservation` avec réponse HTTP `202 Accepted`. La vérification idempotente avec le même fingerprint renvoie `{"booking_request_id":5,"statut":"pending","duplicate":true}`, confirmant que la demande synthétique existe bien une seule fois. Le premier passage a pris environ 13 secondes, compatible avec un réveil/initialisation de connexion PostgreSQL ; l’API a finalement répondu correctement. Aucun envoi externe ni donnée réelle n’a été utilisé.
