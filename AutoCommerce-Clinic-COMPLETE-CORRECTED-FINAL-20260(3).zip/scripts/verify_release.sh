#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
API_DIR="$ROOT_DIR/api-server"
WEB_DIR="$ROOT_DIR/autocommerce-app"

: "${DATABASE_URL:?DATABASE_URL doit pointer vers PostgreSQL pour la vérification}"
: "${REDIS_URL:?REDIS_URL doit pointer vers Redis pour la vérification}"
export ENV="${ENV:-test}"

cd "$API_DIR"
python3 -m compileall -q .
alembic upgrade head
alembic current
alembic heads
pytest -q

cd "$WEB_DIR"
pnpm install --frozen-lockfile --ignore-scripts
pnpm check
pnpm test -- --run
pnpm build

printf '\nVérification de release terminée avec succès.\n'
