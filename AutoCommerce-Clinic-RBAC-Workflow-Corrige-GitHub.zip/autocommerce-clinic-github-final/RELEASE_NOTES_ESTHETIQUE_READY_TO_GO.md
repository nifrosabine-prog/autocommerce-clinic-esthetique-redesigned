# Notes de release — packaging final mono-VPS

Cette archive est désormais positionnée comme **packaging mono-clinique mono-VPS**. Elle n’annonce plus de qualification enterprise implicite.

## Changements clés

- ajout d’un `.env.production.example` minimal et strict ;
- réalignement des docs de déploiement, installation, opérations, backup et rollback ;
- corrections de cohérence sur `CLINIC_ID`, `PUBLIC_CLINIC_ID` et `SOCIAL_WEBHOOK_CLINIC_ID` ;
- correction du script de déploiement initial et de la validation d’infrastructure ;
- ajout de logs structurés avec `request_id` et `correlation_id` ;
- wording assistant IA réaligné avec la réalité technique : déterministe sécurisé par défaut, LLM optionnel.

## Position produit

- **supporté** : une clinique, un VPS, une base dédiée, un Redis dédié ;
- **non qualifié par ce packaging** : production-ready enterprise multi-cliniques.

## Règle finale

Le packaging est prêt à être déployé sur le VPS cible pour exécution de la recette finale. La mention **production ready** reste conditionnée à l’archivage des preuves runtime et restore sur l’infrastructure cible.
