from __future__ import annotations

import json
import os
from pathlib import Path

import requests

BASE = "http://127.0.0.1:8180/api/v1"
REPORT = Path("/home/ubuntu/aesthetic_runtime_audit/BUYER_CLINICAL_VARIANT_REPORT.json")

session = requests.Session()
login = session.post(f"{BASE}/auth/login", json={"identifier": "estheticienne@clinique-esthetique.tn", "password": os.environ["QA_ESTHETICIENNE_PASSWORD"]}, timeout=20)
checks = [{"name": "esthetician_login", "status": login.status_code, "expected": 200, "ok": login.status_code == 200}]
if login.ok:
    session.headers.update({"Authorization": f"Bearer {login.json()['access_token']}"})
    for path in ["/patients", "/patients/1/dossiers"]:
        response = session.get(f"{BASE}{path}", timeout=30)
        checks.append({"name": f"esthetician_{path.strip('/').replace('/', '_')}", "status": response.status_code, "expected": 200, "ok": response.status_code == 200})
report = {"checks": checks, "passed": sum(1 for item in checks if item["ok"]), "failed": sum(1 for item in checks if not item["ok"])}
REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(report, ensure_ascii=False))
raise SystemExit(0 if report["failed"] == 0 else 1)
