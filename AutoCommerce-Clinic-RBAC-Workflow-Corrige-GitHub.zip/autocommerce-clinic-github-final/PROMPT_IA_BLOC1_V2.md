# Bloc 1 — Assistant IA v2

## Périmètre du livrable

Ce livrable concerne **uniquement le Bloc 1** :

* Prompt système structuré en 7 blocs (auditable, modifiable par clinique)
* Détection des détresses médicales → escalade immédiate (avant rate limit)
* Détection des tentatives de prompt injection → refus + journal
* Annulation / reprogrammation / confirmation RDV en mode « proposition
  encadrée » avec jeton HMAC et fenêtre d'annulation
* Escalade humaine après 2 tours consécutifs hors périmètre
* Darija : listes de détresse, intents d'annulation/reprogrammation
* Tests unitaires Bloc 1 (`api-server/tests/test_assistant_bloc1_v2.py`)

Sont **hors périmètre de ce livrable** (livraisons Blocs 2 & 3
prévues ultérieurement) :

* Module paiement de la téléconsultation (Stripe + LiveKit)
* Validation HDS des hôtes (routeur Nginx, certificats, DPA)
* Migration PostgreSQL nouvelle colonne « AssistantSessionContext »

## Fichiers livrés / modifiés

| Fichier | Type | Modification |
|---|---|---|
| `api-server/services/assistant_ia.py` | modifié | Prompt 7 blocs, urgences, injection, propositions encadrées |
| `api-server/services/assistant_security.py` | modifié | CANCELLATION_WINDOW, HMAC, MEDICAL_DISTRESS, record_distress_escalation |
| `api-server/services/assistant_tools_schema.py` | modifié | WRITE_INTENTS étendu + messages FR/darija |
| `api-server/tests/test_assistant_bloc1_v2.py` | créé | 18 tests unitaires (détection, fenêtre, HMAC, darija) |
| `PROMPT_IA_BLOC1_V2.md` | créé | Note de livraison du Bloc 1 |

## Compatibilité descendante

* Les routes HTTP existantes restent inchangées.
* Le système prompt est conservé comme référence auditable —
  l'orchestrateur actuel reste basé sur des regex déterministes
  (Bloc 2 validé en août 2026). Le passage à un orchestrateur
  LLM est planifié et n'impacte pas les contrats externes.
* Les identifiants `WRITE_INTENTS`, `REFUS_HORS_PERIMETRE_MESSAGE`
  restent exportés depuis `assistant_tools_schema`.

## Limites restantes du Bloc 1

* Les propositions encadrées renvoient un jeton court (cosmétique,
  HMAC SHA256) ; la **mutation côté agenda** reste gérée par
  l'orchestrateur amont, qui doit appeler
  ``verify_confirmation_token`` avant tout changement. Cette
  intégration inter-applications n'est pas livrée dans ce Bloc 1.
* La détection de détresse médicale est **déterministe et limitée**.
  Un patient qui s'exprime par SMS avec une formulation non listée
  (ex. « je sens bizarre ») passerait à travers le filet. La
  recommandation est d'ajouter périodiquement de nouveaux patterns
  à partir de l'analyse de messages réels.
* L'escalade humaine déclenche un log ``CRITIQUE`` mais ne
  téléphone pas encore au praticien — l'appel à la cellule
  d'escalade (Number pré-programmé) est câblé dans l'orchestrateur
  externe.
* Aucune vérification du contexte RDV (`rdv_datetime`) n'est encore
  branchée dans l'orchestrateur de test : la fenêtre est vérifiée
  par le helper mais le caller doit fournir ce paramètre.

## Vérifications exécutées

* `python -m py_compile api-server/services/assistant_ia.py`
* `python -m py_compile api-server/services/assistant_security.py`
* `python -m py_compile api-server/services/assistant_tools_schema.py`
* (Tests à exécuter via `pytest api-server/tests/test_assistant_bloc1_v2.py`
  sur un workspace avec les dépendances installées — non exécuté
  dans le sandbox dépourvu de Python complet + DB.)
