# Checklist go-live unique

Projet : __________________________
Clinique : ________________________
VPS cible : _______________________
Version applicative : _____________
Date : ____________________________

## Gate unique

- [ ] `.env.production` final validé
- [ ] `DEPLOYMENT_MODE=internal_single_clinic`
- [ ] `CLINIC_ID` défini
- [ ] `PUBLIC_CLINIC_ID=CLINIC_ID` si public activé
- [ ] `SOCIAL_WEBHOOK_CLINIC_ID=CLINIC_ID` si webhooks activés
- [ ] `CORS_ORIGINS` strict et réel
- [ ] `REFRESH_COOKIE_DOMAIN` réel ou vide assumé
- [ ] `docker compose up -d` complet réussi
- [ ] `alembic upgrade head` réussi
- [ ] `/health` OK
- [ ] `/ready` OK
- [ ] login OK
- [ ] MFA OK
- [ ] refresh OK
- [ ] logout OK
- [ ] booking public -> validation privée OK
- [ ] RBAC par rôle OK
- [ ] isolation clinique OK
- [ ] worker OK
- [ ] beat OK
- [ ] webhook réel ou sandbox OK
- [ ] backup chiffré OK
- [ ] HMAC OK
- [ ] restauration isolée OK
- [ ] comptages/intégrité OK
- [ ] procédure minutée OK
- [ ] logs structurés OK
- [ ] `request_id` / `correlation_id` OK
- [ ] alertes process OK
- [ ] alertes disque OK
- [ ] alertes backup OK
- [ ] alertes erreur applicative OK
- [ ] alertes worker/beat OK
- [ ] rollback testé OK
- [ ] documentation finale relue OK

## Signatures

Exploitant : ______________________
Date/heure : ______________________

Responsable clinique : ____________
Date/heure : ______________________

Décision finale : GO / NO-GO

## Contrôles V2.1 ajoutés

| Contrôle | Résultat attendu |
|---|---|
| Flags sûrs | `LLM_ENABLED=false`, `MEDICAL_AI_PROVIDER_APPROVED=false`, `WHATSAPP_ENABLED=false`, `WEBHOOKS_ENABLED=false` avant configuration. |
| Identité mono-clinique | `CLINIC_ID`, `PUBLIC_CLINIC_ID` et `SOCIAL_WEBHOOK_CLINIC_ID` sont cohérents lorsqu’ils sont activés. |
| Webhooks | Signature vérifiée, taille maximale contrôlée et refus fermé si secret ou mapping absent. |
| WhatsApp | Aucun envoi réel sans token, téléphone, version API et autorisation explicite du mode concerné. |
| Lina | Une question informative n’attend pas de validation ; une écriture sensible et tout message proactif en attend une. |
| Médical | Les demandes de diagnostic, dosage, posologie ou interprétation sont refusées et les détresses escaladées. |
| Facturation | Tests de prix négatif, quantité invalide, remise/TVA hors intervalle, transition de statut et motif d’annulation exécutés. |
| RBAC | Création, activation, désactivation et suppression de comptes testées par rôle ; dernier administrateur protégé. |
| Données | Archive vérifiée sans `.env` réel, credentials, export patient ni dump de production. |

La validation de ces lignes est une condition de go-live, et non une activation automatique des connecteurs.
