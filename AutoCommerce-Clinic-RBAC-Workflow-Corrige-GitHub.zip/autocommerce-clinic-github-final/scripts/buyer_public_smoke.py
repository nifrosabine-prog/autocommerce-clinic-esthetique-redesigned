from __future__ import annotations

import json
from datetime import date, timedelta
from pathlib import Path

import requests

BASE = "http://127.0.0.1:5175/api/public"
REPORT = Path("/home/ubuntu/aesthetic_runtime_audit/BUYER_PUBLIC_SMOKE_REPORT.json")
checks = []


def record(name: str, response: requests.Response, expected: int = 200) -> None:
    try:
        body = response.json()
    except ValueError:
        body = response.text[:300]
    checks.append({"name": name, "status": response.status_code, "expected": expected, "ok": response.status_code == expected, "body": body})


def main() -> int:
    practitioners = requests.get(f"{BASE}/praticiens", timeout=20)
    record("public_practitioners", practitioners)
    acts = requests.get(f"{BASE}/actes", timeout=20)
    record("public_acts", acts)
    if not practitioners.ok or not acts.ok or not practitioners.json() or not acts.json():
        return 1

    practitioner_id = practitioners.json()[0]["id"]
    acte_id = acts.json()[0]["id"]
    target_date = date.today()
    availability = requests.get(f"{BASE}/disponibilites/{practitioner_id}", params={"date": target_date.isoformat(), "acte_id": acte_id}, timeout=20)
    record("public_availability", availability)
    if not availability.ok or not availability.json().get("creneaux"):
        target_date = date.today() + timedelta(days=1)
        availability = requests.get(f"{BASE}/disponibilites/{practitioner_id}", params={"date": target_date.isoformat(), "acte_id": acte_id}, timeout=20)
        record("public_availability_next_day", availability)
    if not availability.ok or not availability.json().get("creneaux"):
        REPORT.write_text(json.dumps({"checks": checks}, ensure_ascii=False, indent=2), encoding="utf-8")
        return 1

    slot = availability.json()["creneaux"][0]["datetime"]
    booking = requests.post(f"{BASE}/reservation", json={"nom": "Acheteur", "prenom": "TestPublic", "telephone": "+21655000888", "praticien_id": practitioner_id, "acte_id": acte_id, "date_heure": slot}, timeout=30)
    record("public_booking_submission", booking, 202)
    report = {"checks": checks, "passed": sum(1 for c in checks if c["ok"]), "failed": sum(1 for c in checks if not c["ok"]), "slot": slot}
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"passed": report["passed"], "failed": report["failed"], "slot": slot}, ensure_ascii=False))
    return 0 if report["failed"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
