# Livraison — corrections landing page MBA Clinic

## Corrections appliquées

Le header a été réorganisé en mobile-first avec un bouton menu accessible, des cibles tactiles renforcées, un logo réduit sur petit écran, un bouton de prise de rendez-vous compact et une navigation mobile dépliable. Le hero s’empile correctement sur mobile et les boutons principaux occupent une largeur confortable.

Trois photos cohérentes ont été intégrées aux cartes des actes : consultation esthétique, soin visage premium et injection esthétique. Elles sont servies depuis les assets publics avec textes alternatifs et chargement différé.

Le bouton « Découvrir le soin » ouvre désormais un contenu détaillé propre à chaque prestation avec bénéfices concrets et CTA de réservation. Les contenus et libellés principaux du hero, du header, de la réservation et des cartes sont disponibles en français et en anglais. Les ressources i18n françaises et anglaises ont été complétées pour le header.

## Vérifications

| Contrôle | Résultat |
|---|---|
| TypeScript `pnpm --dir autocommerce-app check` | Réussi |
| Build `pnpm --dir autocommerce-app build` | Réussi |
| API `/health` | `{"status":"ok"}` |
| API `/ready` | PostgreSQL et Redis OK |
| Rendu mobile 390×844 | Header compact, menu visible, CTA pleine largeur, hero lisible |
| Changement de langue FR → EN | Header, hero, formulaire principal et cartes vérifiés |
| Interaction « Découvrir le soin » | Détails et CTA affichés avec succès |

Les autres textes secondaires du formulaire de rappel, du contact et du pied de page restent fonctionnels en français ; ils pourront constituer une seconde passe i18n si la clinique souhaite une traduction anglaise exhaustive de chaque libellé métier.
