"""
AutoCommerce Clinic — API Agenda
"""

from datetime import datetime
from decimal import Decimal
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field, field_validator
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from models.database import (
    RendezVous, Patient, Utilisateur, ActeMedical, StatutRDV, DossierMedical, UtilisationLot,
)
from api.deps import get_db
from middleware.clinic_rbac import require_role
from models.database import RoleEnum

from services.agenda import get_disponibilites, creer_rdv, annuler_rdv
from services.stock_injectable import register_usage
from services.audit_medical import log_access

router = APIRouter(prefix="/agenda", tags=["agenda"])


# ── Schémas ────────────────────────────────────────────────

class RDVCreate(BaseModel):
    patient_id: int
    praticien_id: int
    acte_id: int
    date_heure: str  # ISO datetime
    salle: Optional[str] = Field(None, max_length=50)


class RDVUpdate(BaseModel):
    statut: Optional[str] = None
    notes_pre_acte: Optional[str] = None
    notes_post_acte: Optional[str] = None
    produits_lots: Optional[list[dict]] = None


    @field_validator("statut")
    @classmethod
    def statut_doit_etre_valide(cls, v):
        if v is not None:
            valeurs = [s.value for s in StatutRDV]
            if v not in valeurs:
                raise ValueError(f"statut invalide, doit être l'un de : {', '.join(valeurs)}")
        return v


class RDVOut(BaseModel):
    id: int
    patient_id: int
    patient_nom: str
    praticien_id: int
    praticien_nom: str
    acte_id: Optional[int]
    acte_nom: Optional[str]
    date_heure_debut: str
    date_heure_fin: Optional[str]
    salle: Optional[str]
    statut: str
    consentement_manquant: bool = False

    class Config:
        from_attributes = True


# ── Routes ─────────────────────────────────────────────────

@router.get("", response_model=List[RDVOut])
async def list_agenda(
    praticien_id: Optional[int] = Query(None),
    patient_id: Optional[int] = Query(None),
    date_debut: Optional[str] = Query(None),
    date_fin: Optional[str] = Query(None),
    vue: str = Query("semaine", pattern="^(semaine|jour)$"),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.DIRECTRICE, RoleEnum.MEDECIN, RoleEnum.ESTHETICIENNE, RoleEnum.ASSISTANTE, RoleEnum.ADMIN)),
):
    """Liste les RDV (vue semaine ou jour)."""
    role = current_user.get("role")
    if role in {RoleEnum.MEDECIN.value, RoleEnum.ESTHETICIENNE.value} and praticien_id not in (None, current_user.get("id")):
        raise HTTPException(status_code=403, detail="Un praticien ne peut consulter que son propre agenda")
    query = select(RendezVous, Patient, Utilisateur, ActeMedical).join(
        Patient, RendezVous.patient_id == Patient.id
    ).join(
        Utilisateur, RendezVous.praticien_id == Utilisateur.id
    ).outerjoin(
        ActeMedical, RendezVous.acte_id == ActeMedical.id
    ).where(RendezVous.clinic_id == current_user["clinic_id"])

    if praticien_id:
        query = query.where(RendezVous.praticien_id == praticien_id)
    elif current_user.get("role") in {RoleEnum.MEDECIN.value, RoleEnum.ESTHETICIENNE.value}:
        query = query.where(RendezVous.praticien_id == current_user["id"])

    if patient_id:
        query = query.where(RendezVous.patient_id == patient_id)

    if date_debut:
        dt_debut = datetime.fromisoformat(date_debut)
        query = query.where(RendezVous.date_heure_debut >= dt_debut)

    if date_fin:
        dt_fin = datetime.fromisoformat(date_fin)
        query = query.where(RendezVous.date_heure_debut <= dt_fin)

    query = query.order_by(RendezVous.date_heure_debut)
    result = await db.execute(query)

    rdvs = []
    for rdv, patient, praticien, acte in result.all():
        from services.consentement import verify_consent
        consent_missing = not await verify_consent(
            rdv.patient_id,
            rdv.acte_id,
            db,
            clinic_id=current_user["clinic_id"],
        )

        rdvs.append(RDVOut(
            id=rdv.id,
            patient_id=rdv.patient_id,
            patient_nom=f"{patient.prenom} {patient.nom}",
            praticien_id=rdv.praticien_id,
            praticien_nom=f"{praticien.prenom} {praticien.nom}",
            acte_id=rdv.acte_id,
            acte_nom=acte.nom if acte else None,
            date_heure_debut=rdv.date_heure_debut.isoformat(),
            date_heure_fin=rdv.date_heure_fin.isoformat() if rdv.date_heure_fin else None,
            salle=rdv.salle,
            statut=rdv.statut,
            consentement_manquant=consent_missing,
        ))

    return rdvs


@router.post("/rdv", response_model=RDVOut)
async def create_rdv(
    data: RDVCreate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.DIRECTRICE, RoleEnum.ASSISTANTE, RoleEnum.ADMIN)),
):
    """Crée un rendez-vous."""
    try:
        date_heure = datetime.fromisoformat(data.date_heure)
        rdv, consent_missing = await creer_rdv(
            patient_id=data.patient_id,
            praticien_id=data.praticien_id,
            acte_id=data.acte_id,
            date_heure=date_heure,
            salle=data.salle,
            db=db,
            created_by=current_user["id"],
            clinic_id=current_user["clinic_id"],
        )

        # Récupérer noms
        patient_r = await db.execute(select(Patient).where(
            Patient.id == data.patient_id,
            Patient.clinic_id == current_user["clinic_id"],
        ))
        patient = patient_r.scalar_one()
        praticien_r = await db.execute(select(Utilisateur).where(
            Utilisateur.id == data.praticien_id,
            Utilisateur.clinic_id == current_user["clinic_id"],
        ))
        praticien = praticien_r.scalar_one()
        acte_r = await db.execute(select(ActeMedical).where(
            ActeMedical.id == data.acte_id,
            ActeMedical.clinic_id == current_user["clinic_id"],
        ))
        acte = acte_r.scalar_one()

        return RDVOut(
            id=rdv.id,
            patient_id=rdv.patient_id,
            patient_nom=f"{patient.prenom} {patient.nom}",
            praticien_id=rdv.praticien_id,
            praticien_nom=f"{praticien.prenom} {praticien.nom}",
            acte_id=rdv.acte_id,
            acte_nom=acte.nom,
            date_heure_debut=rdv.date_heure_debut.isoformat(),
            date_heure_fin=rdv.date_heure_fin.isoformat() if rdv.date_heure_fin else None,
            salle=rdv.salle,
            statut=rdv.statut,
            consentement_manquant=consent_missing,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.patch("/rdv/{rdv_id}/statut")
@router.put("/rdv/{rdv_id}/statut")
async def update_rdv_statut(
    rdv_id: int,
    data: RDVUpdate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.DIRECTRICE, RoleEnum.ASSISTANTE, RoleEnum.MEDECIN, RoleEnum.ESTHETICIENNE, RoleEnum.ADMIN)),
):
    """Met à jour le statut d'un RDV."""
    result = await db.execute(select(RendezVous).where(
        RendezVous.id == rdv_id,
        RendezVous.clinic_id == current_user["clinic_id"],
    ))
    rdv = result.scalar_one_or_none()
    if not rdv:
        raise HTTPException(status_code=404, detail="RDV non trouvé")

    if data.statut == StatutRDV.TERMINE.value and current_user.get("role") in {
        RoleEnum.MEDECIN.value,
        RoleEnum.ESTHETICIENNE.value,
    }:
        if rdv.praticien_id != current_user.get("id"):
            raise HTTPException(status_code=403, detail="Seul le praticien affecté peut clôturer ce rendez-vous")

    if data.statut:
        rdv.statut = data.statut
    if data.notes_pre_acte is not None:
        rdv.notes_pre_acte = data.notes_pre_acte
    if data.notes_post_acte is not None:
        rdv.notes_post_acte = data.notes_post_acte

    # La clôture d'un rendez-vous est le point métier de réalisation de
    # l'intervention standard. Les lots indiqués dans le dossier sont débités
    # une seule fois, avec un marqueur d'idempotence lié au rendez-vous.
    if data.statut == StatutRDV.TERMINE.value:
        dossier = await db.scalar(select(DossierMedical).where(
            DossierMedical.rdv_id == rdv.id,
            DossierMedical.patient_id == rdv.patient_id,
            DossierMedical.clinic_id == current_user["clinic_id"],
        ))
        if dossier:
            produits_lots = data.produits_lots
            if produits_lots is None and isinstance(dossier.produits_utilises, dict):
                produits_lots = dossier.produits_utilises.get("lots") or []
            produits_lots = produits_lots or []
            marker = f"rdv_id:{rdv.id}"
            already_registered = await db.scalar(select(UtilisationLot.id).where(
                UtilisationLot.clinic_id == current_user["clinic_id"],
                UtilisationLot.dossier_id == dossier.id,
                UtilisationLot.notes.ilike(f"%{marker}%"),
            ))
            if not already_registered:
                for lot_item in produits_lots:
                    lot_id = lot_item.get("lot_id")
                    quantity = lot_item.get("quantite", lot_item.get("quantite_utilisee"))
                    if not lot_id or quantity is None:
                        raise HTTPException(status_code=422, detail="Chaque lot doit contenir lot_id et quantite")
                    await register_usage(
                        lot_id=int(lot_id),
                        dossier_id=dossier.id,
                        patient_id=rdv.patient_id,
                        praticien_id=rdv.praticien_id,
                        quantite=Decimal(str(quantity)),
                        unite=str(lot_item.get("unite") or "unité"),
                        db=db,
                        type_injection=lot_item.get("type_injection"),
                        date_injection=datetime.utcnow(),
                        notes=f"{lot_item.get('notes') or ''} [{marker}]".strip(),
                        clinic_id=current_user["clinic_id"],
                    )

    await log_access(
        db=db,
        utilisateur_id=current_user["id"],
        patient_id=rdv.patient_id,
        action="UPDATE_RDV_STATUS",
        resource_type="rendez_vous",
        resource_id=rdv.id,
        clinic_id=current_user["clinic_id"],
        details={"statut": rdv.statut, "produits_lots": data.produits_lots or []},
    )
    await db.flush()
    return {"message": "RDV mis à jour", "statut": rdv.statut}


@router.delete("/rdv/{rdv_id}")
async def cancel_rdv_route(
    rdv_id: int,
    raison: Optional[str] = Query(None, min_length=3),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.DIRECTRICE, RoleEnum.ASSISTANTE, RoleEnum.ADMIN)),
):
    """Annule un RDV."""
    if raison is None:
        raison = "Annulation sans raison spécifiée (via API DELETE)"
    """Annule un RDV."""
    try:
        rdv = await annuler_rdv(
            rdv_id,
            raison,
            db,
            clinic_id=current_user["clinic_id"],
        )
        return {"message": "RDV annulé", "rdv_id": rdv.id}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.get("/disponibilites/{praticien_id}")
async def get_dispos(
    praticien_id: int,
    date: str = Query(..., description="YYYY-MM-DD"),
    duree: int = Query(30, ge=15, le=240),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.DIRECTRICE, RoleEnum.ASSISTANTE, RoleEnum.MEDECIN, RoleEnum.ESTHETICIENNE, RoleEnum.ADMIN)),
):
    """Créneaux libres d'un praticien pour une date."""
    if current_user.get("role") in {RoleEnum.MEDECIN.value, RoleEnum.ESTHETICIENNE.value} and praticien_id != current_user.get("id"):
        raise HTTPException(status_code=403, detail="Un praticien ne peut consulter que ses propres disponibilités")
    date_jour = datetime.strptime(date, "%Y-%m-%d").date()
    creneaux = await get_disponibilites(
        praticien_id,
        date_jour,
        duree,
        db,
        clinic_id=current_user["clinic_id"],
    )
    return {"praticien_id": praticien_id, "date": date, "creneaux": creneaux}
