from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPORTS = [
    ROOT / "ROLE_SIMULATION_REPORT.json",
    ROOT / "SUPER_ADMIN_SMOKE_REPORT.json",
    ROOT / "PROXY_ROLE_SMOKE_REPORT.json",
]
SENSITIVE_KEYS = {"access_token", "refresh_token", "password", "hashed_password", "challenge_token"}


def redact(value):
    if isinstance(value, dict):
        return {key: "[REDACTED]" if key in SENSITIVE_KEYS else redact(item) for key, item in value.items()}
    if isinstance(value, list):
        return [redact(item) for item in value]
    return value


for path in REPORTS:
    if path.exists():
        data = json.loads(path.read_text(encoding="utf-8"))
        path.write_text(json.dumps(redact(data), ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"redacted {path.name}")
