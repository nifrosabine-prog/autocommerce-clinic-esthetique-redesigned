# Opérations — mono-VPS clinique

L’exploitation doit surveiller en continu :

- santé applicative : `/health` et `/ready`
- état Docker : `docker compose ps`
- worker et beat
- espace disque des volumes de données et du support de backup
- erreurs applicatives structurées
- succès/échec des sauvegardes

## Observabilité attendue

Le backend émet désormais des logs structurés avec `request_id` et `correlation_id`. Le reverse proxy et les outils d’exploitation doivent propager `X-Request-ID` et `X-Correlation-ID` pour garder une traçabilité de bout en bout.

Les alertes minimales à activer sur le VPS cible sont :

- process down sur API, worker, beat, PostgreSQL, Redis et Nginx ;
- seuil disque haut sur les volumes applicatifs et le répertoire de backup ;
- échec ou absence de backup ;
- hausse anormale des erreurs applicatives 5xx ;
- non-réponse de worker ou beat.

## Discipline opérationnelle

Chaque incident doit produire :

- un horodatage ;
- un `request_id` ou `correlation_id` lorsqu’il existe ;
- la version déployée ;
- la cause supposée ;
- l’action menée ;
- le résultat ;
- la décision rollback ou fix forward.
