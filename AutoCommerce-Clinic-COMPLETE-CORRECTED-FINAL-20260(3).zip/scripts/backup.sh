#!/bin/sh
# Sauvegarde périodique AutoCommerce Clinic (mono-VPS) :
#   1. base PostgreSQL : pg_dump (format custom compressé) ;
#   2. données patients : photos + uploads + branding (tar.gz horodaté).
# Purge automatique des archives de plus de RETENTION_DAYS jours.
# Exécuté en boucle par le service "backup" du docker-compose.production.yml
# (pas de cron externe requis).
#
# Variables d'environnement : POSTGRES_DB, POSTGRES_USER, PGPASSWORD, PGHOST,
#   DATA_DIR (dossier des données, ex /data), BACKUP_DIR (dossier des dumps),
#   BACKUP_INTERVAL_SECONDS, RETENTION_DAYS.
set -eu

BACKUP_DIR="${BACKUP_DIR:-/backups}"
DATA_DIR="${DATA_DIR:-/data}"
RETENTION_DAYS="${RETENTION_DAYS:-14}"
INTERVAL="${BACKUP_INTERVAL_SECONDS:-86400}"

mkdir -p "$BACKUP_DIR"

echo "[backup] service démarré — intervalle=${INTERVAL}s, rétention=${RETENTION_DAYS}j, données=${DATA_DIR}"

while true; do
  TIMESTAMP="$(date -u +%Y%m%dT%H%M%SZ)"
  DB_FILE="${BACKUP_DIR}/${POSTGRES_DB}_${TIMESTAMP}.dump"
  DATA_FILE="${BACKUP_DIR}/${POSTGRES_DB}_${TIMESTAMP}_data.tar.gz"

  # 1) Base de données
  echo "[backup] $(date -u +%FT%TZ) — pg_dump vers ${DB_FILE}"
  if pg_dump -h "${PGHOST}" -U "${POSTGRES_USER}" -d "${POSTGRES_DB}" -F c -f "${DB_FILE}.tmp"; then
    mv "${DB_FILE}.tmp" "${DB_FILE}"
    echo "[backup] DB OK — $(du -h "${DB_FILE}" | cut -f1)"
  else
    echo "[backup] ÉCHEC pg_dump — voir logs ci-dessus" >&2
    rm -f "${DB_FILE}.tmp"
  fi

  # 2) Données (photos / uploads / branding)
  # Des écritures concurrentes (api/worker) peuvent produire un instantané
  # légèrement incohérent ; acceptable pour un MVP — préférer une heure
  # creuse en réglant BACKUP_INTERVAL_SECONDS.
  echo "[backup] archive des données (${DATA_DIR}) vers ${DATA_FILE}"
  if tar -czf "${DATA_FILE}.tmp" -C "$DATA_DIR" . 2>/dev/null; then
    mv "${DATA_FILE}.tmp" "${DATA_FILE}"
    echo "[backup] DATA OK — $(du -h "${DATA_FILE}" | cut -f1)"
  else
    echo "[backup] ÉCHEC tar des données — voir logs ci-dessus" >&2
    rm -f "${DATA_FILE}.tmp"
  fi

  # 3) Purge des archives périmées
  echo "[backup] purge des archives de plus de ${RETENTION_DAYS} jours"
  find "$BACKUP_DIR" -name "${POSTGRES_DB}_*.dump" -mtime +"${RETENTION_DAYS}" -print -delete || true
  find "$BACKUP_DIR" -name "${POSTGRES_DB}_*_data.tar.gz" -mtime +"${RETENTION_DAYS}" -print -delete || true

  sleep "$INTERVAL"
done
