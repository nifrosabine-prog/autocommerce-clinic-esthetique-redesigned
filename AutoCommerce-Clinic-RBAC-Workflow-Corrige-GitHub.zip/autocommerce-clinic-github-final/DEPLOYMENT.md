# Déploiement — packaging mono-clinique mono-VPS

Ce livrable est préparé pour **une clinique sur un VPS dédié**. La pile de référence comprend PostgreSQL, Redis, API FastAPI, Celery worker, Celery beat, frontend et reverse proxy Nginx sur la même machine.

## Référence officielle

- mode par défaut : `DEPLOYMENT_MODE=internal_single_clinic`
- identifiant clinique global requis : `CLINIC_ID`
- routes publiques supportées si `PUBLIC_ROUTES_ENABLED=true`
- webhooks supportés si `WEBHOOKS_ENABLED=true`
- en mode mono-clinique, `PUBLIC_CLINIC_ID` et `SOCIAL_WEBHOOK_CLINIC_ID` doivent toujours être égaux à `CLINIC_ID`

## Séquence standard

```bash
cp .env.production.example /etc/autocommerce/.env.production
chmod 600 /etc/autocommerce/.env.production
# remplacer toutes les valeurs par les vraies valeurs

export ADMIN_EMAIL='admin@clinique.example'
export ADMIN_PASSWORD='<secret-long-fourni-hors-dépôt>'
API_ENV_FILE=/etc/autocommerce/.env.production ./scripts/verify_infrastructure.sh
DEPLOY_ENV_FILE=/etc/autocommerce/.env.production ./scripts/first_deploy.sh
```

## Domaines et alignement

Le packaging suppose quatre noms distincts côté exploitation :

- `APP_DOMAIN` : frontend public
- `PUBLIC_API_DOMAIN` : API publique `/api/public`
- `PRIVATE_APP_DOMAIN` : frontend clinique privé
- `PRIVATE_API_DOMAIN` : API privée `/api/private` et `/api/v1`

`CORS_ORIGINS` doit reprendre exactement les origines HTTPS réellement servies. `REFRESH_COOKIE_DOMAIN` doit pointer vers le domaine réel partagé par les surfaces qui utilisent le cookie de refresh, ou rester vide si l’exploitation choisit un cookie host-only.

## Frontières réseau

- PostgreSQL et Redis ne doivent jamais être publiés sur l’hôte.
- L’API ne doit être liée qu’à `127.0.0.1:8000`.
- Le frontend ne doit être lié qu’à `127.0.0.1:8080`.
- Le reverse proxy est le seul composant exposé sur 80/443.

## Qualification finale

Ce packaging ne peut être qualifié **production ready** qu’après preuves runtime réelles sur le VPS cible : compose complet, migrations, smoke test, restore validé, observabilité active et archivage des traces dans le dossier de preuves VPS.
