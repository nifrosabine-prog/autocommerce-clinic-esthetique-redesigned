from __future__ import annotations

import json
import os
from pathlib import Path

import requests

BASE = "http://127.0.0.1:8100/api/v1"
REPORT = Path("/home/ubuntu/aesthetic_runtime_audit/SUPER_ADMIN_SMOKE_REPORT.json")
checks = []


def check(name: str, response: requests.Response, expected: int) -> None:
    try:
        body = response.json()
    except ValueError:
        body = response.text[:500]
    checks.append({"name": name, "status": response.status_code, "expected": expected, "ok": response.status_code == expected, "body": body})


def main() -> int:
    super_session = requests.Session()
    login = super_session.post(f"{BASE}/auth/login", json={"identifier": os.environ.get("SUPER_ADMIN_IDENTIFIER", "anas@superadmin.nt"), "password": os.environ["SUPER_ADMIN_PASSWORD"]}, timeout=20)
    check("login_identifier", login, 200)
    if login.status_code == 200:
        super_session.headers.update({"Authorization": f"Bearer {login.json()['access_token']}"})
        me = super_session.get(f"{BASE}/auth/me", timeout=20)
        check("me_super_admin", me, 200)

        for endpoint in ["dashboard", "clinics", "users", "health", "performance", "subscriptions"]:
            response = super_session.get(f"{BASE}/super-admin/{endpoint}", timeout=30)
            check(endpoint, response, 200)

        subscriptions = super_session.get(f"{BASE}/super-admin/subscriptions", timeout=20)
        if subscriptions.status_code == 200 and subscriptions.json():
            sid = subscriptions.json()[0]["id"]
            suspended = super_session.patch(f"{BASE}/super-admin/subscriptions/{sid}", json={"status": "suspended"}, timeout=20)
            check("suspend_subscription", suspended, 200)
            restored = super_session.patch(f"{BASE}/super-admin/subscriptions/{sid}", json={"status": "active"}, timeout=20)
            check("restore_subscription", restored, 200)

    clinic_session = requests.Session()
    clinic_login = clinic_session.post(f"{BASE}/auth/login", json={"identifier": "admin@clinique-esthetique.tn", "password": os.environ["QA_ADMIN_PASSWORD"]}, timeout=20)
    check("clinic_login_identifier", clinic_login, 200)
    if clinic_login.status_code == 200:
        clinic_session.headers.update({"Authorization": f"Bearer {clinic_login.json()['access_token']}"})
        denied = clinic_session.get(f"{BASE}/super-admin/dashboard", timeout=20)
        check("clinic_denied_super_admin", denied, 403)

    report = {"checks": checks, "passed": sum(1 for c in checks if c["ok"]), "failed": sum(1 for c in checks if not c["ok"])}
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"passed": report["passed"], "failed": report["failed"]}, ensure_ascii=False))
    print(f"report={REPORT}")
    return 0 if report["failed"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
