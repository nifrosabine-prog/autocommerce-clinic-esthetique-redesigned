# Périmètre des modules — V2.1

Le produit est livré pour une seule clinique sur un seul VPS. Le classement ci-dessous décrit le niveau de maturité livré ; il ne constitue pas une promesse de fonctionnalités hors périmètre.

| Classement | Modules | Lecture de livraison |
|---|---|---|
| **Prêt** | Landing + réservation publique ; agenda / planning ; patients ; stock injectables et consommables | Parcours opérationnels principaux inclus, sous réserve de la configuration et des tests go-live. |
| **Correct** | Facturation ; équipe / RH ; workflows / automatisations ; Lina ; omnicanal ; délégués & laboratoires ; commissions ; messages d’équipe ; recrutement | Fonctionnalités utilisables et sécurisées, mais nécessitant procédures internes et validation métier. |
| **Partiel** | Téléconsultation ; reporting / tableaux de bord avancés | Périmètre limité ; aucune téléconsultation complète ni BI avancée n’est engagée. |
| **Non supporté** | Multi-clinique / Enterprise ; haute disponibilité ; multi-VPS | Explicitement hors architecture et hors engagement de cette version. |

## Règles transverses

L’authentification, le cloisonnement par `clinic_id`, le RBAC, la journalisation et la configuration explicite des intégrations sont des prérequis. Les secrets et données de production doivent être injectés uniquement au déploiement.

## Points d’attention client

La facturation utilise `Decimal` pour les calculs et impose des transitions de statuts cohérentes. Lina répond automatiquement aux demandes informatives fiables, tandis que les écritures, les actions sensibles et les messages proactifs restent contrôlés. WhatsApp et les webhooks sont opt-in et fail-closed lorsqu’une configuration critique manque.

## Références internes

[1]: ./LIVRAISON_CLIENT.md "Remise client"
[2]: ./LIMITES_ASSISTANT_IA.md "Limites Lina"
[3]: ./GO_LIVE_CHECKLIST.md "Checklist go-live"

## Références

[1]: ./LIVRAISON_CLIENT.md "Remise client"
[2]: ./LIMITES_ASSISTANT_IA.md "Limites Lina"
[3]: ./GO_LIVE_CHECKLIST.md "Checklist go-live"
