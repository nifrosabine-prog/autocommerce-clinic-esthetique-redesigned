from datetime import datetime, timedelta

import pytest
from datetime import timezone
from sqlalchemy import select

from api.v1.clinical_operations import (
    CureCreate,
    EvenementCreate,
    SeanceStatusPatch,
    create_adverse_event,
    create_cure,
    update_cure_session,
    list_global_clinical_audit,
)
from models.database import EvenementIndesirable, SeanceCure, SuiviPostActe, Facture, AuditLogFinancial
from services.audit_medical import log_access


@pytest.mark.asyncio
async def test_global_audit_merges_medical_and_financial_entries(db, medecin, assistante, patient):
    facture = Facture(
        clinic_id=1,
        patient_id=patient.id,
        numero_facture="F-TEST-AUDIT-001",
        sous_total=100,
        taux_tva=0.19,
        montant_tva=19,
        total_ttc=119,
        statut="payee",
    )
    db.add(facture)
    await db.flush()
    await log_access(
        db=db,
        utilisateur_id=medecin.id,
        patient_id=patient.id,
        action="CREATE_DOSSIER",
        resource_type="dossier",
        resource_id=42,
        clinic_id=1,
    )
    db.add(AuditLogFinancial(
        clinic_id=1,
        entite_type="facture",
        entite_id=facture.id,
        action="paiement",
        valeur_apres={"mode_paiement": "especes"},
        modifie_par_id=assistante.id,
    ))
    await db.flush()

    entries = await list_global_clinical_audit(
        date_debut=None,
        date_fin=None,
        role=None,
        action=None,
        current_user={"id": assistante.id, "role": "directrice", "clinic_id": 1},
        patient_id=patient.id,
        limit=20,
        db=db,
    )
    actions = {entry["action"] for entry in entries}
    assert "CREATE_DOSSIER" in actions
    assert "FACTURE_PAIEMENT" in actions
    payment = next(entry for entry in entries if entry["action"] == "FACTURE_PAIEMENT")
    assert payment["details"]["numero_facture"] == "F-TEST-AUDIT-001"


@pytest.mark.asyncio
async def test_create_cure_generates_sessions(db, medecin, patient, acte):
    payload = CureCreate(
        patient_id=patient.id,
        acte_id=acte.id,
        nom="Peeling visage",
        seances_prevues=3,
        premiere_seance_at=datetime.utcnow() + timedelta(days=1),
    )
    result = await create_cure(payload, {"id": medecin.id, "role": "medecin", "clinic_id": 1}, db)
    assert result["seances_prevues"] == 3
    assert len(result["seances"]) == 3
    assert result["seances"][0]["statut"] == "planifiee"


@pytest.mark.asyncio
async def test_realised_session_creates_one_followup(db, medecin, patient, acte):
    cure = await create_cure(CureCreate(
        patient_id=patient.id, acte_id=acte.id, nom="Cure test", seances_prevues=1,
    ), {"id": medecin.id, "role": "medecin", "clinic_id": 1}, db)
    session_id = cure["seances"][0]["id"]
    session = await db.scalar(select(SeanceCure).where(SeanceCure.id == session_id))
    session.suivi_recommande_le = datetime.utcnow().date() + timedelta(days=7)
    await db.flush()

    await update_cure_session(
        cure_id=cure["id"],
        seance_id=session_id,
        payload=SeanceStatusPatch(statut="realisee"),
        current_user={"id": medecin.id, "role": "medecin", "clinic_id": 1},
        db=db,
    )
    followups = (await db.execute(select(SuiviPostActe).where(SuiviPostActe.seance_id == session_id))).scalars().all()
    assert len(followups) == 1
    assert followups[0].patient_id == patient.id


@pytest.mark.asyncio
async def test_realised_session_accepts_timezone_aware_datetime(db, medecin, patient, acte):
    cure = await create_cure(CureCreate(
        patient_id=patient.id, acte_id=acte.id, nom="Cure timezone", seances_prevues=1,
    ), {"id": medecin.id, "role": "medecin", "clinic_id": 1}, db)
    session_id = cure["seances"][0]["id"]
    aware = datetime.utcnow().replace(tzinfo=timezone.utc)
    result = await update_cure_session(
        cure_id=cure["id"],
        seance_id=session_id,
        payload=SeanceStatusPatch(statut="realisee", realisee_at=aware),
        current_user={"id": medecin.id, "role": "medecin", "clinic_id": 1},
        db=db,
    )
    assert result["seances"][0]["statut"] == "realisee"


@pytest.mark.asyncio
async def test_adverse_event_is_scoped_to_authenticated_clinic(db, medecin, patient):
    result = await create_adverse_event(
        EvenementCreate(
            patient_id=patient.id,
            survenu_at=datetime.utcnow(),
            description="Rougeur persistante après le soin",
            gravite="moderee",
        ),
        {"id": medecin.id, "role": "medecin", "clinic_id": 1},
        db,
    )
    event = await db.scalar(select(EvenementIndesirable).where(EvenementIndesirable.id == result["id"]))
    assert event is not None
    assert event.clinic_id == 1


@pytest.mark.asyncio
async def test_adverse_event_accepts_timezone_aware_datetime(db, medecin, patient):
    result = await create_adverse_event(
        EvenementCreate(
            patient_id=patient.id,
            survenu_at=datetime.utcnow().replace(tzinfo=timezone.utc),
            description="Réaction synthétique timezone",
            gravite="faible",
        ),
        {"id": medecin.id, "role": "medecin", "clinic_id": 1},
        db,
    )
    assert result["statut"] == "ouvert"


@pytest.mark.asyncio
async def test_cross_clinic_patient_is_rejected(db, medecin, patient):
    from fastapi import HTTPException
    from models.database import Patient

    other_patient = Patient(clinic_id=2, nom="Autre", prenom="Tenant", telephone="+21621111111")
    db.add(other_patient)
    await db.flush()
    with pytest.raises(HTTPException) as exc:
        await create_adverse_event(
            EvenementCreate(
                patient_id=other_patient.id,
                survenu_at=datetime.utcnow(),
                description="Tentative hors tenant",
            ),
            {"id": medecin.id, "role": "medecin", "clinic_id": 1},
            db,
        )
    assert exc.value.status_code == 404
