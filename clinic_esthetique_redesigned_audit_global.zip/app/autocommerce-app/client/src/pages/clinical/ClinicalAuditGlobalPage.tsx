import { useEffect, useState } from 'react';
import { ArrowLeft, Filter, RefreshCw, ShieldCheck } from 'lucide-react';
import { useLocation } from 'wouter';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { clinicalOpsApi } from '@/lib/api';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

type AuditDetails = Record<string, unknown>;

export interface ClinicalAuditEntry {
  id: number | string;
  created_at: string;
  utilisateur_id?: number;
  utilisateur: string;
  role: string;
  patient_id: number;
  patient: string;
  action: string;
  resource_type: string;
  resource_id: number;
  details?: AuditDetails;
}

const formatDateTime = (value?: string | null) => value
  ? new Date(value).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' })
  : '—';

const detailValue = (details: AuditDetails | undefined, key: string) => {
  const value = details?.[key];
  return value === undefined || value === null || value === '' ? null : String(value);
};

export default function ClinicalAuditGlobalPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [entries, setEntries] = useState<ClinicalAuditEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filters, setFilters] = useState({ patient_id: '', date_debut: '', date_fin: '', role: '', action: '', limit: '200' });

  const load = async () => {
    if (!['directrice', 'admin'].includes(user?.role || '')) return;
    try {
      setLoading(true);
      setError('');
      const response = await clinicalOpsApi.listGlobalAudit({
        patient_id: filters.patient_id ? Number(filters.patient_id) : undefined,
        date_debut: filters.date_debut || undefined,
        date_fin: filters.date_fin || undefined,
        role: filters.role || undefined,
        action: filters.action || undefined,
        limit: Math.min(500, Math.max(1, Number(filters.limit) || 200)),
      });
      setEntries(response.data as ClinicalAuditEntry[]);
    } catch (err: any) {
      const message = err.response?.data?.detail || 'Impossible de charger le journal clinique global';
      setError(message);
      toast.error(message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, [user?.role]);

  const updateFilter = (key: keyof typeof filters, value: string) => {
    setFilters((current) => ({ ...current, [key]: value }));
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">Traçabilité et conformité</p>
            <h1 className="mt-1 text-3xl font-bold tracking-tight">Journal clinique global</h1>
            <p className="mt-2 max-w-3xl text-muted-foreground">Une chronologie unique des opérations médicales et financières : qui a fait quoi, pour quel patient et à quel moment.</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setLocation('/clinical-ops')}><ArrowLeft className="mr-2 h-4 w-4" />Retour au suivi</Button>
            <Button variant="outline" onClick={() => void load()} disabled={loading}><RefreshCw className={`mr-2 h-4 w-4 ${loading ? 'animate-spin' : ''}`} />Actualiser</Button>
          </div>
        </div>

        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><Filter className="h-5 w-5 text-primary" />Filtres du journal</CardTitle></CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-6">
            <div><Label htmlFor="audit-patient">Patient ID</Label><Input id="audit-patient" inputMode="numeric" value={filters.patient_id} onChange={(event) => updateFilter('patient_id', event.target.value)} placeholder="Tous" /></div>
            <div><Label htmlFor="audit-start">Du</Label><Input id="audit-start" type="date" value={filters.date_debut} onChange={(event) => updateFilter('date_debut', event.target.value)} /></div>
            <div><Label htmlFor="audit-end">Au</Label><Input id="audit-end" type="date" value={filters.date_fin} onChange={(event) => updateFilter('date_fin', event.target.value)} /></div>
            <div><Label htmlFor="audit-role">Rôle</Label><Input id="audit-role" value={filters.role} onChange={(event) => updateFilter('role', event.target.value)} placeholder="medecin" /></div>
            <div><Label htmlFor="audit-action">Action</Label><Input id="audit-action" value={filters.action} onChange={(event) => updateFilter('action', event.target.value)} placeholder="FACTURE_PAIEMENT" /></div>
            <div className="flex items-end"><Button className="w-full" onClick={() => void load()} disabled={loading}>Appliquer</Button></div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="flex items-center justify-between gap-3"><span>Événements ({entries.length})</span><span className="inline-flex items-center gap-1 text-xs font-normal text-muted-foreground"><ShieldCheck className="h-4 w-4" />Accès direction/admin</span></CardTitle></CardHeader>
          <CardContent>
            {loading && <p className="py-10 text-center text-muted-foreground">Chargement du journal…</p>}
            {!loading && error && <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-800"><p>{error}</p><Button className="mt-3" variant="outline" onClick={() => void load()}>Réessayer</Button></div>}
            {!loading && !error && entries.length === 0 && <p className="py-10 text-center text-muted-foreground">Aucune activité ne correspond aux filtres.</p>}
            {!loading && !error && entries.length > 0 && (
              <div className="overflow-x-auto rounded-lg border">
                <table className="min-w-[980px] w-full text-sm">
                  <thead className="bg-muted/50 text-left text-xs uppercase tracking-wide text-muted-foreground">
                    <tr><th className="px-3 py-3">Date / heure</th><th className="px-3 py-3">Action</th><th className="px-3 py-3">Ressource</th><th className="px-3 py-3">Patient</th><th className="px-3 py-3">Acteur</th><th className="px-3 py-3">Rôle</th><th className="px-3 py-3">Détails</th></tr>
                  </thead>
                  <tbody className="divide-y">
                    {entries.map((entry) => {
                      const invoice = detailValue(entry.details, 'numero_facture');
                      const amount = detailValue(entry.details, 'total_ttc');
                      const payment = detailValue(entry.details, 'mode_paiement');
                      const detailText = [invoice, amount ? `${amount} TTC` : null, payment].filter(Boolean).join(' · ');
                      return <tr key={entry.id} className="align-top hover:bg-muted/30"><td className="whitespace-nowrap px-3 py-3 text-muted-foreground">{formatDateTime(entry.created_at)}</td><td className="px-3 py-3 font-semibold">{entry.action.replaceAll('_', ' ')}</td><td className="px-3 py-3">{entry.resource_type} #{entry.resource_id}</td><td className="px-3 py-3">{entry.patient} <span className="text-xs text-muted-foreground">#{entry.patient_id}</span></td><td className="px-3 py-3">{entry.utilisateur}</td><td className="px-3 py-3 capitalize">{entry.role}</td><td className="px-3 py-3 text-muted-foreground">{detailText || '—'}</td></tr>;
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
