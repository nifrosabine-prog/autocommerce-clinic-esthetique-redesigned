# Corrections AutoCommerce Clinic — rapport de livraison

**Date :** 27 août 2026  
**Base :** archive fournie par l’utilisateur, travaillée dans une copie dédiée.  
**Données de production :** aucune donnée existante supprimée ou modifiée.

## Verdict

Les corrections demandées pour les trois défauts ciblés sont implémentées dans la copie de travail : **navigation Agenda**, **permissions de routes et d’actions**, et **liaison intervention–stock injectable**. La qualité statique et les suites de tests disponibles sont vertes. Le déploiement Railway et le parcours navigateur en production n’ont pas été modifiés depuis cette archive ; ils doivent être rejoués après publication de cette version.

## Corrections réalisées

### Stock et intervention

La création d’un dossier médical accepte désormais une liste structurée `produits_lots` contenant `lot_id`, `quantite`, `unite` et éventuellement des notes. Ces lots sont conservés dans le dossier sans être débités prématurément.

Lorsqu’un rendez-vous passe à `termine`, l’API recherche le dossier lié au rendez-vous et débite les lots associés avec verrouillage transactionnel, contrôle de quantité, contrôle d’expiration et vérification du tenant déjà fournis par `register_usage`. Un marqueur `rdv_id:<id>` rend l’opération idempotente et empêche un double débit lors d’un second PATCH ou d’un rechargement.

Le débit est journalisé dans `AuditLogMedical` avec le patient, le dossier, le lot, la quantité, le praticien et l’utilisateur déclencheur. La clôture du rendez-vous est elle-même journalisée comme `UPDATE_RDV_STATUS`. La création de lots injectables est désormais limitée à la directrice et à l’administrateur, et l’interface ne présente plus les boutons de création de lots/consommables aux autres rôles.

Le formulaire médical affiche une section explicite **Consommation de l’intervention**. Si aucun lot n’est requis, l’utilisateur doit laisser cette section vide ; ce cas est distingué d’une absence silencieuse de fonctionnalité.

### Navigation Agenda

Le menu latéral utilise `/agenda` pour le calendrier et `/clinical-ops` pour **Suivi des soins**. La navigation Agenda utilise maintenant un lien HTML réel avec `href` et conserve la navigation SPA. Les deux libellés et routes sont séparés et ne doivent plus être confondus.

### Permissions

Les routes `/agenda`, `/stock` et `/invoices` ont des garde-fous frontend explicites. Le commercial n’a plus accès aux routes Agenda, Stock ou Factures, y compris par navigation directe côté frontend. La route `/patients` et la fiche patient restent disponibles au commercial pour ses patientes, mais la fiche est limitée aux informations d’identité et n’affiche ni données médicales, ni consentements, ni photos, ni export PDF.

La matrice RBAC backend ne donne plus au commercial les permissions `agenda:read` ou `factures:read`. La page Factures reste réservée à la directrice, à l’assistante et à l’administrateur, conformément aux opérations de facturation. La modale patient n’affiche les champs médicaux chiffrés que pour les rôles cliniques `medecin` et `estheticienne`; la directrice peut donc créer ou modifier l’identité administrative sans recevoir un formulaire qui sera ensuite refusé pour des champs médicaux.

Le backend refuse également qu’un praticien crée un dossier au nom d’un autre utilisateur et qu’un médecin clôture le rendez-vous d’un autre praticien. Le contrôle ne repose donc pas uniquement sur la visibilité du menu.

## Fichiers principaux modifiés

| Fichier | Modification |
|---|---|
| `api-server/middleware/clinic_rbac.py` | Matrice commerciale réalignée et dépendance `require_permission` ajoutée |
| `api-server/api/v1/agenda_clinic.py` | Lots à la clôture, idempotence, restriction du praticien, audit de statut |
| `api-server/api/v1/dossiers_medicaux.py` | Champ `produits_lots` et contrôle du praticien connecté |
| `api-server/services/dossier_medical.py` | Persistance structurée des lots prévus sans débit prématuré |
| `api-server/tests/test_dossier_medical.py` | Régression lots structurés et politique des routes sensibles |
| `api-server/api/v1/stock_injectable.py` | Création de lots réservée à la gestion stock et audit des consommations |
| `api-server/api/v1/consommables.py` | Imports corrigés et scoping `clinic_id` appliqué à chaque opération |
| `autocommerce-app/client/src/App.tsx` | Garde-fous de routes par rôle |
| `autocommerce-app/client/src/components/layout/DashboardLayout.tsx` | Navigation Agenda déterministe et menu Factures réaligné |
| `autocommerce-app/client/src/pages/patients/MedicalFile.tsx` | Protection de la vue médicale et saisie des lots d’intervention |
| `autocommerce-app/client/src/pages/patients/PatientsList.tsx` | Bouton Éditer masqué pour le commercial |
| `autocommerce-app/client/src/components/patients/PatientFormDialog.tsx` | Séparation identité / champs médicaux |
| `autocommerce-app/client/src/pages/stock/StockPage.tsx` | Bouton Ajouter un lot conditionné par le rôle |
| `autocommerce-app/client/src/components/stock/ConsommablesList.tsx` | Bouton Nouveau consommable conditionné par le rôle |
| `autocommerce-app/client/src/lib/api.ts` | Contrat TypeScript `produits_lots` |

## Validations exécutées

| Contrôle | Résultat |
|---|---:|
| Tests backend ciblés | 69 réussis |
| Suite backend complète | **555 réussis, 1 ignoré** |
| Ruff sur les fichiers backend modifiés | **PASS** |
| Compilation Python | **PASS** |
| Typecheck frontend `pnpm check` | **PASS** |
| Tests frontend Vitest | **69 réussis dans 12 fichiers** |
| Build frontend `pnpm build` | **PASS** |

## Tests à rejouer après déploiement

Le bundle corrigé doit être publié sur un environnement de recette. Il faut ensuite tester avec le commercial les accès directs `/agenda`, `/stock` et `/invoices`; avec l’assistante le clic Menu → Agenda; avec le médecin la création d’un dossier et la clôture de son propre rendez-vous; puis avec la directrice la réception d’un lot, la réalisation d’une intervention avec un lot de test, le contrôle de la décrémentation, la répétition de la clôture et la vérification du journal global.

Le test d’intégration stock recommandé est : créer un lot fictif de quantité 5, créer un dossier avec `produits_lots=[{"lot_id": <id>, "quantite": 1, "unite": "unité"}]`, clôturer le rendez-vous, vérifier le stock à 4, répéter la clôture et vérifier que le stock reste à 4. Tester également un lot expiré et une quantité supérieure au stock.

## Intégrité des fichiers fournis

Le fichier `SHA256SUMS_REPORT_FIXES` reçu ne référence pas l’archive ZIP fournie : il mentionne notamment `frontend-dist.tar.gz` et une autre archive absente du répertoire. Sa vérification ne permet donc pas de certifier l’intégrité du ZIP reçu. Une nouvelle somme SHA-256 de l’archive corrigée est fournie séparément dans la livraison.

## Limite de livraison

Cette livraison contient les corrections dans le code source et le bundle frontend reconstruit localement. Elle ne publie pas automatiquement sur Railway et ne modifie pas la base de données distante. Une migration de schéma n’est pas nécessaire pour ces changements : la relation utilise les champs existants `DossierMedical.produits_utilises` et `UtilisationLot`.
