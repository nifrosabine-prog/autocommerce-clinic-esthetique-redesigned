import React, { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/lib/api';
import { Spinner } from '@/components/ui/spinner';
import {
  AlertCircle,
  ArrowUpRight,
  Calendar,
  CheckCircle2,
  Clock3,
  DollarSign,
  FileText,
  MessageCircle,
  PackageSearch,
  Sparkles,
  TrendingUp,
  Users,
} from 'lucide-react';
import { Link } from 'wouter';
import { PointageWidget } from '@/components/dashboard/PointageWidget';

interface DashboardStats {
  todayAppointments: number;
  stockAlerts: number;
  unpaidInvoices: number;
  socialMessages: number;
}

function todayLocalDate(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

const statCards = [
  {
    key: 'todayAppointments' as const,
    label: "Rendez-vous aujourd'hui",
    helper: 'agenda du jour',
    icon: Calendar,
    accent: 'bg-blue-50 text-blue-700',
    href: '/agenda',
  },
  {
    key: 'stockAlerts' as const,
    label: 'Alertes stock',
    helper: 'produits à surveiller',
    icon: PackageSearch,
    accent: 'bg-amber-50 text-amber-700',
    href: '/stock',
  },
  {
    key: 'unpaidInvoices' as const,
    label: 'Factures à suivre',
    helper: 'en attente de paiement',
    icon: DollarSign,
    accent: 'bg-emerald-50 text-emerald-700',
    href: '/invoices',
  },
  {
    key: 'socialMessages' as const,
    label: 'Messages à traiter',
    helper: 'demandes sociales nouvelles',
    icon: MessageCircle,
    accent: 'bg-violet-50 text-violet-700',
    href: '/social',
  },
];

export default function Dashboard() {
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState<DashboardStats>({
    todayAppointments: 0,
    stockAlerts: 0,
    unpaidInvoices: 0,
    socialMessages: 0,
  });

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        setIsLoading(true);
        const today = todayLocalDate();
        const [agendaRes, stockRes, facturesRes, socialRes] = await Promise.allSettled([
          api.get(`/agenda?date_debut=${today}T00:00:00&date_fin=${today}T23:59:59&vue=jour`),
          api.get('/injectables/stock'),
          api.get('/factures'),
          api.get('/social/analytics'),
        ]);

        let todayAppointments = 0;
        if (agendaRes.status === 'fulfilled' && Array.isArray(agendaRes.value.data)) {
          todayAppointments = agendaRes.value.data.length;
        }

        let stockAlerts = 0;
        if (stockRes.status === 'fulfilled' && stockRes.value.data?.total_alertes !== undefined) {
          stockAlerts = stockRes.value.data.total_alertes;
        }

        let unpaidInvoices = 0;
        if (facturesRes.status === 'fulfilled' && Array.isArray(facturesRes.value.data)) {
          unpaidInvoices = facturesRes.value.data.filter((f: { statut: string }) =>
            ['envoyee', 'partiellement_payee'].includes(f.statut)
          ).length;
        }

        let socialMessages = 0;
        if (socialRes.status === 'fulfilled' && socialRes.value.data?.messages) {
          const msgs = socialRes.value.data.messages;
          socialMessages = Object.values(msgs).reduce(
            (total: number, platformStats: any) => total + (platformStats.nouveau || 0),
            0,
          );
        }

        setStats({ todayAppointments, stockAlerts, unpaidInvoices, socialMessages });
      } finally {
        setIsLoading(false);
      }
    };

    loadDashboardData();
  }, []);

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex min-h-[28rem] items-center justify-center">
          <Spinner />
        </div>
      </DashboardLayout>
    );
  }

  const displayName = `${user?.prenom || ''} ${user?.nom || ''}`.trim();
  const today = new Intl.DateTimeFormat('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(new Date());

  return (
    <DashboardLayout>
      <div className="mx-auto max-w-[1500px] space-y-6 pb-8">
        <section className="relative overflow-hidden rounded-[1.5rem] bg-[#071a3b] px-6 py-7 text-white shadow-[0_20px_60px_-28px_rgba(7,26,59,0.7)] sm:px-8 sm:py-9">
          <div className="absolute -right-20 -top-24 h-72 w-72 rounded-full bg-cyan-400/20 blur-3xl" />
          <div className="absolute bottom-[-6rem] left-1/3 h-52 w-52 rounded-full bg-blue-500/20 blur-3xl" />
          <div className="relative flex flex-col justify-between gap-7 lg:flex-row lg:items-end">
            <div>
              <div className="mb-4 flex items-center gap-2 text-xs font-medium uppercase tracking-[0.18em] text-cyan-200">
                <Sparkles className="h-4 w-4" />
                Pilotage clinique
              </div>
              <h1 className="max-w-2xl text-3xl font-semibold tracking-tight sm:text-4xl">
                Bonjour {displayName || 'à vous'}.
              </h1>
              <p className="mt-2 max-w-xl text-sm leading-6 text-blue-100/75">
                Une vision claire de l’activité essentielle de votre clinique, sans bruit et sans métriques décoratives.
              </p>
            </div>
            <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/10 px-4 py-3 backdrop-blur-sm">
              <Clock3 className="h-5 w-5 text-cyan-200" />
              <div>
                <p className="text-[11px] uppercase tracking-[0.14em] text-blue-100/60">Aujourd’hui</p>
                <p className="mt-1 text-sm font-medium capitalize">{today}</p>
              </div>
            </div>
          </div>
        </section>

        <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {statCards.map((item) => {
            const Icon = item.icon;
            const value = stats[item.key];
            return (
              <Link href={item.href} key={item.key} className="group block">
                <Card className="h-full rounded-2xl border-slate-200/80 bg-white shadow-sm transition-all duration-200 group-hover:-translate-y-0.5 group-hover:border-blue-200 group-hover:shadow-lg">
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between gap-4">
                      <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${item.accent}`}>
                        <Icon className="h-5 w-5" />
                      </div>
                      <ArrowUpRight className="h-4 w-4 text-slate-300 transition-colors group-hover:text-blue-600" />
                    </div>
                    <p className="mt-5 text-sm font-medium text-slate-600">{item.label}</p>
                    <div className="mt-1 flex items-end justify-between gap-3">
                      <p className="text-3xl font-semibold tracking-tight text-[#071a3b]">{value}</p>
                      <TrendingUp className="mb-1 h-4 w-4 text-emerald-500" />
                    </div>
                    <p className="mt-1 text-xs text-slate-400">{item.helper}</p>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </section>

        <div className="grid grid-cols-1 gap-6 xl:grid-cols-[minmax(0,1.35fr)_minmax(320px,0.65fr)]">
          <Card className="overflow-hidden rounded-2xl border-emerald-100 bg-gradient-to-br from-emerald-50 via-white to-cyan-50 shadow-sm">
            <CardContent className="p-6 sm:p-7">
              <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-start">
                <div>
                  <div className="flex items-center gap-2 text-sm font-semibold text-emerald-900">
                    <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                    État opérationnel
                  </div>
                  <p className="mt-3 max-w-xl text-sm leading-6 text-slate-600">
                    Les indicateurs affichés sont issus des modules Agenda, Stock, Facturation et Social CRM. Utilisez les cartes ci-dessus pour accéder directement à l’action utile.
                  </p>
                </div>
                <div className="rounded-xl bg-white/80 px-4 py-3 text-right shadow-sm ring-1 ring-emerald-100">
                  <p className="text-[11px] uppercase tracking-[0.14em] text-slate-400">Priorité du jour</p>
                  <p className="mt-1 text-sm font-semibold text-emerald-800">
                    {stats.stockAlerts > 0 ? 'Vérifier le stock' : stats.unpaidInvoices > 0 ? 'Suivre les règlements' : 'Tout est sous contrôle'}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <PointageWidget />
        </div>

        <Card className="rounded-2xl border-slate-200/80 bg-white shadow-sm">
          <CardContent className="p-6">
            <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.16em] text-blue-600">Accès rapide</p>
                <h2 className="mt-1 text-xl font-semibold tracking-tight text-[#071a3b]">Passer de l’indicateur à l’action</h2>
              </div>
              <p className="text-sm text-slate-500">Les raccourcis conservent les routes existantes.</p>
            </div>
            <div className="mt-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
              {[
                { href: '/agenda', label: 'Agenda', icon: Calendar },
                { href: '/patients', label: 'Patients', icon: Users },
                { href: '/invoices', label: 'Factures', icon: FileText },
                { href: '/stock', label: 'Stock', icon: AlertCircle },
              ].map(({ href, label, icon: Icon }) => (
                <Link href={href} key={href} className="flex items-center justify-between rounded-xl border border-slate-200 px-4 py-3 text-sm font-medium text-slate-700 transition-colors hover:border-blue-200 hover:bg-blue-50 hover:text-blue-800">
                  <span className="flex items-center gap-3"><Icon className="h-4 w-4 text-blue-600" />{label}</span>
                  <ArrowUpRight className="h-4 w-4 text-slate-300" />
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
