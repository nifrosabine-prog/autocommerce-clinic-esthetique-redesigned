from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from sqlalchemy import select
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

ROOT = Path(__file__).resolve().parents[1]
API = ROOT / "api-server"
sys.path.insert(0, str(API))
load_dotenv(API / ".env.runtime.staging")

from middleware.auth import get_password_hash  # noqa: E402
from models.database import Utilisateur  # noqa: E402

PASSWORDS = {
    "directrice@clinique-esthetique.tn": os.environ["QA_DIRECTRICE_PASSWORD"],
    "medecin@clinique-esthetique.tn": os.environ["QA_MEDECIN_PASSWORD"],
    "estheticienne@clinique-esthetique.tn": os.environ["QA_ESTHETICIENNE_PASSWORD"],
    "assistante@clinique-esthetique.tn": os.environ["QA_ASSISTANTE_PASSWORD"],
    "commercial@clinique-esthetique.tn": os.environ["QA_COMMERCIAL_PASSWORD"],
    "admin@clinique-esthetique.tn": os.environ["QA_ADMIN_PASSWORD"],
}

async def main() -> None:
    engine = create_async_engine(os.environ["DATABASE_URL"], pool_pre_ping=True)
    session_factory = async_sessionmaker(engine, expire_on_commit=False)
    async with session_factory() as db:
        for email, password in PASSWORDS.items():
            user = await db.scalar(select(Utilisateur).where(Utilisateur.email == email))
            if user is None:
                raise RuntimeError(f"Compte absent: {email}")
            user.hashed_password = get_password_hash(password)
            user.is_active = True
        await db.commit()
    await engine.dispose()
    print("runtime QA passwords reset for", ", ".join(PASSWORDS))
    print("passwords are intentionally not printed")

if __name__ == "__main__":
    asyncio.run(main())
