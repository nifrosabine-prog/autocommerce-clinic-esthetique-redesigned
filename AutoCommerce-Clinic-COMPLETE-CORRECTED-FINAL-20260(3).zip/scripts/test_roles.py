import os
import sys
import requests

BASE = os.environ.get("API_BASE", "http://127.0.0.1:18000")
USERS = [
    ("directrice", "admin@clinic.local", "QA-Directrice-2026!"),
    ("medecin", "medecin@clinic.local", "QA-Medecin-2026!"),
    ("assistante", "assistante@clinic.local", "QA-Assistante-2026!"),
    ("commercial", "commercial@clinic.local", "QA-Commercial-2026!"),
    ("estheticienne", "estheticienne@clinic.local", "QA-Estheticienne-2026!"),
]


def expect(response, status, label):
    if response.status_code != status:
        raise AssertionError(f"{label}: attendu {status}, reçu {response.status_code}: {response.text[:300]}")


def main():
    expect(requests.get(f"{BASE}/health", timeout=5), 200, "health")
    ready = requests.get(f"{BASE}/ready", timeout=5)
    expect(ready, 200, "ready")
    assert ready.json() == {"status": "ready", "postgres": "ok", "redis": "ok"}

    results = []
    tokens = {}
    for role, email, password in USERS:
        response = requests.post(
            f"{BASE}/api/v1/auth/login",
            json={"identifier": email, "password": password},
            timeout=10,
        )
        expect(response, 200, f"login {role}")
        payload = response.json()
        assert payload.get("access_token"), f"{role}: access_token absent"
        tokens[role] = payload["access_token"]
        me = requests.get(
            f"{BASE}/api/v1/auth/me",
            headers={"Authorization": f"Bearer {payload['access_token']}"},
            timeout=10,
        )
        expect(me, 200, f"me {role}")
        assert me.json()["role"] == role, f"{role}: rôle retourné incorrect {me.json()}"
        results.append({"role": role, "login": "OK", "me": "OK"})

    # Directrice : gestion équipe autorisée.
    response = requests.get(
        f"{BASE}/api/v1/users",
        headers={"Authorization": f"Bearer {tokens['directrice']}"},
        timeout=10,
    )
    expect(response, 200, "directrice users")

    # Les rôles métier ne doivent pas accéder à la gestion des utilisateurs.
    for role in ("medecin", "assistante", "commercial", "estheticienne"):
        response = requests.get(
            f"{BASE}/api/v1/users",
            headers={"Authorization": f"Bearer {tokens[role]}"},
            timeout=10,
        )
        expect(response, 403, f"RBAC users {role}")

    # Les rôles non administratifs ne doivent pas accéder aux métriques protégées.
    for role in ("medecin", "assistante", "commercial", "estheticienne"):
        response = requests.get(
            f"{BASE}/metrics",
            headers={"Authorization": f"Bearer {tokens[role]}"},
            timeout=10,
        )
        expect(response, 403, f"RBAC metrics {role}")

    print({"health": "OK", "ready": "OK", "roles": results, "rbac": "OK"})


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ROLE_TEST_FAILED: {exc}", file=sys.stderr)
        raise
