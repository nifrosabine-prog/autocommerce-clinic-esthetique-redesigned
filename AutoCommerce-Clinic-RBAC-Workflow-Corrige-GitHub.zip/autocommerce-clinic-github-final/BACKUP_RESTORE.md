# Backup et restauration

Une sauvegarde n’est considérée valide qu’après :

1. chiffrement réussi ;
2. HMAC vérifié ;
3. restauration sur PostgreSQL isolé ;
4. comparaison de comptages ;
5. exécution minutée et archivée.

## Sauvegarde chiffrée

```bash
sudo ENV_FILE=/etc/autocommerce/.env.production bash scripts/backup_postgres.sh
```

Le script :

- produit un `pg_dump` ;
- compresse le flux ;
- chiffre en AES-256-CBC + PBKDF2 ;
- écrit un HMAC sidecar ;
- refuse par défaut un répertoire situé sur le même device que `/`.

## Restauration sur instance isolée

```bash
sudo BACKUP_FILE=/var/backups/autocommerce-clinic/<fichier>.sql.gz.enc      BACKUP_ENCRYPTION_KEY='<clé>'      bash scripts/validate_backup_restore.sh
```

Le contrôle valide la présence du HMAC, le déchiffrement, `gunzip -t`, l’import dans une PostgreSQL isolée et des comptages minimums.

## Preuve de restaurabilité à archiver

Archiver sur le VPS cible :

- nom du backup ;
- taille du backup ;
- résultat HMAC ;
- durée de restauration ;
- comptages avant/après ;
- version applicative testée ;
- opérateur ;
- date et heure.

Sans cette preuve réelle, ne pas utiliser la mention **production ready**.
