import json
import os
import sys
from pathlib import Path

import requests

base = os.environ.get('OPENAI_APP_BASE', 'http://127.0.0.1:8000').rstrip('/')
email = os.environ['E2E_ADMIN_EMAIL']
password = os.environ['E2E_ADMIN_PASSWORD']
login = requests.post(
    f'{base}/api/private/auth/login',
    json={'identifier': email, 'password': password},
    timeout=30,
)
print('OPENAI_APP_LOGIN_STATUS=', login.status_code)
login.raise_for_status()
token = login.json()['access_token']
response = requests.post(
    f'{base}/api/v1/assistant-ia/ask',
    headers={'Authorization': f'Bearer {token}', 'Accept': 'application/json'},
    json={'question': 'Réponds en une phrase : quelle est la capitale de la Tunisie ?'},
    timeout=90,
)
print('OPENAI_APP_ASK_STATUS=', response.status_code)
try:
    payload = response.json()
except json.JSONDecodeError:
    print('OPENAI_APP_RESPONSE=non_json')
    print(response.text[:300])
    sys.exit(1)
print('OPENAI_APP_PROVIDER=', payload.get('provider'))
print('OPENAI_APP_MODEL=', payload.get('model'))
print('OPENAI_APP_ERROR=', payload.get('error'))
answer = str(payload.get('answer', ''))
print('OPENAI_APP_ANSWER_PREVIEW=', answer[:240].replace('\n', ' '))
if response.status_code != 200:
    sys.exit(1)
if payload.get('error'):
    sys.exit(2)
if not answer.strip():
    sys.exit(3)
print('OPENAI_APP_PROBE=PASS')
