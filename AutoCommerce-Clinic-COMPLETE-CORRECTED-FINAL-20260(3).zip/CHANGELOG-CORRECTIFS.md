# CHANGELOG — Correctifs reprise après sinistre (archive VPS-READY corrigée)

Date : 2026-09-06
Base : `AutoCommerce-Clinic-recette-PURIFIE-VPS-READY.zip`
Portée : correctifs identifiés lors de l'audit « ready to go » (mono-VPS),
appliqués et validés dans cette archive. Aucune autre modification.

## 1. docker-compose.production.yml

- **`scripts/restore.sh` désormais monté** dans le service `backup`
  (`./scripts/restore.sh:/scripts/restore.sh:ro`) — la restauration
  documentée dans le README échouait car `/scripts/restore.sh` n'existait
  pas dans le conteneur (image stock `postgres:16-alpine`).
- **Volume `clinic_data:/data` monté** dans `backup` — les photos, uploads
  et branding patients sont désormais sauvegardés (avant : base seule,
  alors que le template WhatsApp `backup_ok` annonce « Base + photos »).
- **`mem_limit` ajouté sur les 8 services** (total 3328 Mo) — protège un
  VPS < 4 Go contre l'OOM killer (image API lourde : OpenCV).

## 2. scripts/backup.sh (réécrit)

- `pg_dump` (format custom compressé) **+ archive tar.gz horodatée** de
  `DATA_DIR` (`/data` → photos/uploads/branding) :
  `<db>_<timestamp>.dump` et `<db>_<timestamp>_data.tar.gz`.
- Purge des archives de plus de `RETENTION_DAYS` jours (les deux types).
- Boucle infinie (pas de cron externe) ; l'échec d'un volet (db ou data)
  ne bloque pas l'autre.

## 3. scripts/restore.sh (réécrit)

- Restaure **base + données** :
  `... exec -T backup sh /scripts/restore.sh <dump.dump> [archive_donnees.tar.gz]`
- Garde-fous : message d'usage (exit 1), vérification de l'existence des
  fichiers avec liste des sauvegardes disponibles, délai d'annulation 5 s
  (`RESTORE_GRACE_SECONDS`), `pg_restore --clean --if-exists --no-owner
  --no-privileges`.
- Rappel dans la sortie : arrêter `api worker beat` avant une restauration
  cohérente, vider `/data` si une copie exacte est requise.

## Validations effectuées

- `docker-compose --env-file deploy/production.env -f docker-compose.production.yml config -q` → exit 0 (env généré temporairement puis supprimé).
- `bash -n` / `sh -n` sur les 3 scripts → OK.
- Test fonctionnel backup/restore avec simulateurs : 3 itérations backup
  OK ; restauration complète → `diff -r` « IDENTIQUES » ; cas d'erreur
  (usage, fichier absent) → exit 1 propre.

## Fichiers modifiés / ajoutés dans ce lot

- `docker-compose.production.yml` (modifié)
- `scripts/backup.sh` (réécrit)
- `scripts/restore.sh` (réécrit)
- `CHANGELOG-CORRECTIFS.md` (ce fichier)

## 4. Sauvegarde hors-site (rsync + SSH)

- `scripts/offsite_sync.sh` (nouveau) : synchro miroir `rsync` (SSH par
  clé) des volumes `clinic_backups` + `clinic_data` vers une cible
  distante — `--delete` reflète la rétention locale, `flock` anti-doublon,
  code rsync 24 toléré, alerte webhook optionnelle en cas d'échec,
  dry-run (`-n` / `OFFSITE_DRY_RUN=true`).
- `deploy/offsite.env.example` (nouveau) : modèle de config
  (`/etc/autocommerce/offsite.env`, chmod 600).
- `docs/OFFSITE_BACKUP.md` (nouveau) : mise en place, cron / systemd
  timer, surveillance et procédure de restauration depuis la copie hors-site.

Fichiers ajoutés dans ce lot :

- `scripts/offsite_sync.sh`
- `deploy/offsite.env.example`
- `docs/OFFSITE_BACKUP.md`
