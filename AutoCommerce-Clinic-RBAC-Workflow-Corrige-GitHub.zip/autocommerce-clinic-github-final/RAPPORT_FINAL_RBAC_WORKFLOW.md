# Rapport final — RBAC, routes et workflows

## Corrections appliquées

Le frontend protège désormais les routes interdites par redirection vers `/dashboard` au lieu d’afficher une page finale « Accès refusé ». Les contrôles backend restent inchangés et continuent de protéger les APIs, le périmètre clinique et le périmètre praticien.

La route historique `/pricing` dispose maintenant d’un alias vers la route canonique `/settings/actes`, ce qui évite la 404 observée lors du test utilisateur. Les factures ont également été alignées sur les rôles réellement autorisés : la route n’est plus accessible au commercial.

Le formulaire de workflow propose désormais un mode simple par défaut. L’utilisateur choisit un délai, une unité, une action, un message et le mode de validation. La configuration technique est générée automatiquement. Les champs JSON sont conservés uniquement dans les options avancées. La validation humaine reste sélectionnée par défaut.

La création est toujours enregistrée en brouillon et ne déclenche aucune communication. Les actions sensibles restent soumises à validation avant exécution.

## Validation

| Contrôle | Résultat |
|---|---:|
| TypeScript frontend | Réussi |
| Build frontend production | Réussi |
| Tests frontend | 69 réussis |
| Tests backend | 587 réussis, 1 ignoré |
| Compilation Python | Réussie |
| Test RBAC des routes interdites | Réussi |
| Alias `/pricing` | Ajouté |
| Workflow guidé sans JSON | Ajouté |
| Mode avancé JSON | Conservé |

La suite backend doit être exécutée avec `REFRESH_COOKIE_SECURE=true`, conformément aux exigences de production HTTPS. L’échec observé sans cette variable correspondait à une configuration locale non sécurisée et non à une régression applicative.

## Limites restantes

La redirection frontend ne remplace pas les contrôles backend. Les APIs doivent rester protégées et continuer à être testées séparément. Le mode simple génère les configurations compatibles avec le modèle backend existant ; les actions avancées et certains connecteurs peuvent encore nécessiter le mode avancé ou une configuration de clinique.

Les données de recette et les secrets réels ne doivent pas être commités dans GitHub. L’archive GitHub exclut les dépendances, environnements virtuels, builds, caches et fichiers d’environnement locaux.
