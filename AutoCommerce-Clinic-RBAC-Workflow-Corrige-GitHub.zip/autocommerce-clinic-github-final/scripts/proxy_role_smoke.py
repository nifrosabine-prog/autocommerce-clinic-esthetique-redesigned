from __future__ import annotations

import json
import os
from pathlib import Path

import requests

BASE = "http://127.0.0.1:8180/api/v1"
REPORT = Path("/home/ubuntu/aesthetic_runtime_audit/PROXY_ROLE_SMOKE_REPORT.json")
ACCOUNTS = {
    "receptionniste": ("assistante@clinique-esthetique.tn", os.environ.get("QA_ASSISTANTE_PASSWORD", "")),
    "praticien": ("medecin@clinique-esthetique.tn", os.environ.get("QA_MEDECIN_PASSWORD", "")),
    "comptable": ("directrice@clinique-esthetique.tn", os.environ.get("QA_DIRECTRICE_PASSWORD", "")),
    "admin": ("admin@clinique-esthetique.tn", os.environ.get("QA_ADMIN_PASSWORD", "")),
    "super_admin": (os.environ.get("SUPER_ADMIN_IDENTIFIER", "anas@superadmin.nt"), os.environ.get("SUPER_ADMIN_PASSWORD", "")),
}
SCENARIOS = {
    "receptionniste": ["/agenda", "/patients", "/factures"],
    "praticien": ["/agenda", "/patients/1/dossiers"],
    "comptable": ["/factures", "/factures/audit-logs", "/commissions", "/business-intelligence/kpi-dashboard"],
    "admin": ["/users", "/salles", "/settings/actes"],
    "super_admin": ["/super-admin/dashboard", "/super-admin/clinics", "/super-admin/health", "/super-admin/performance", "/super-admin/subscriptions"],
}

checks = []


def add(role: str, action: str, response: requests.Response, expected: int = 200) -> None:
    try:
        body = response.json()
    except ValueError:
        body = response.text[:200]
    checks.append({"role": role, "action": action, "status": response.status_code, "expected": expected, "ok": response.status_code == expected, "body": body})


def main() -> int:
    for role, credentials in ACCOUNTS.items():
        session = requests.Session()
        response = session.post(f"{BASE}/auth/login", json={"identifier": credentials[0], "password": credentials[1]}, timeout=20)
        add(role, "login_identifier", response)
        if response.status_code != 200:
            continue
        session.headers.update({"Authorization": f"Bearer {response.json()['access_token']}"})
        me = session.get(f"{BASE}/auth/me", timeout=20)
        add(role, "me", me)
        for endpoint in SCENARIOS[role]:
            result = session.get(f"{BASE}{endpoint}", timeout=30)
            add(role, endpoint, result)

    report = {"base": BASE, "checks": checks, "passed": sum(1 for c in checks if c["ok"]), "failed": sum(1 for c in checks if not c["ok"])}
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"passed": report["passed"], "failed": report["failed"]}, ensure_ascii=False))
    print(f"report={REPORT}")
    return 0 if report["failed"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
