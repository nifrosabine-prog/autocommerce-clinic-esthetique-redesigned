# AutoCommerce Clinic

Application clinique composée de deux services :

- `api-server/` : API FastAPI, migrations Alembic et tests Python ;
- `autocommerce-app/` : application React/Vite, tests Vitest et tests Playwright.

## Démarrage local

```bash
cd api-server
python -m pip install -r requirements.txt
alembic upgrade head
python main.py
```

Dans un second terminal :

```bash
cd autocommerce-app
pnpm install --frozen-lockfile
pnpm dev
```

Les variables sensibles doivent être fournies par l'environnement d'exécution,
jamais ajoutées au dépôt. Les fichiers `.db` et les dépendances installées sont
des artefacts locaux et sont exclus par `.gitignore`.

## Vérifications

```bash
cd api-server && pytest -q
cd ../autocommerce-app && pnpm check && pnpm test && pnpm build
```

Le rapport des corrections appliquées se trouve dans
`docs/Plan_global_de_correction_par_roles_20260904.md`.

## Déploiement production conteneurisé

La composition `docker-compose.production.yml` fournit sept services :

| Service | Rôle |
|---|---|
| `postgres` | Base de données, volume persistant, healthcheck |
| `redis` | Broker/backend Celery, volume persistant, healthcheck |
| `api` | API FastAPI ; exécute `api-server/start.sh` au démarrage (`alembic upgrade head` puis bootstrap admin optionnel puis Uvicorn) |
| `worker` | Worker Celery — exécute les tâches asynchrones (scan de factures IA, fidélité, super-admin...) définies dans `services/celery_app.py` |
| `beat` | Planificateur Celery — déclenche le `beat_schedule` (rappels J-1/H-2, alertes stock, anniversaires) |
| `web` | Frontend buildé, servi par Nginx sur le port interne `8080` (non exposé directement) |
| `caddy` | Reverse-proxy TLS public — HTTPS automatique (Let's Encrypt) sur `DOMAIN`, ports `80`/`443` |
| `backup` | `pg_dump` quotidien vers le volume `clinic_backups`, purge après `RETENTION_DAYS` jours |

### Préparer le déploiement

1. Sur le VPS (jamais en local), générer le fichier de secrets réel :
   ```bash
   cd deploy && ./generate_production_env.sh
   ```
   Le script demande le `DOMAIN` (DNS déjà pointé vers le VPS) et génère
   lui-même `POSTGRES_PASSWORD`, `SECRET_KEY`, `FERNET_KEY`,
   `PHOTO_ENCRYPTION_KEY`, `MFA_ENCRYPTION_KEY` avec `openssl rand`
   (`chmod 600`, jamais committé ni relivré dans une archive).
   Vérifier/adapter ensuite `POSTGRES_DB`, `POSTGRES_USER`, `WEB_PORT`
   si besoin dans `deploy/production.env`.
2. Si un compte direction initial est nécessaire, décommenter
   `BOOTSTRAP_ADMIN_EMAIL`/`BOOTSTRAP_ADMIN_PASSWORD` dans
   `deploy/production.env`, démarrer une fois, puis **retirer ces deux
   lignes** du fichier — ne jamais laisser tourner le seed QA
   (`docs/RECETTE_LOCALE.md`, comptes `qa.*@clinic.local`) en production.
3. Ouvrir uniquement les ports `80`/`443` sur le pare-feu (`ufw allow
   80,443/tcp && ufw enable`) — `web` n'est jamais exposé directement,
   tout passe par `caddy`.
4. Si une clé OpenAI est nécessaire (`LLM_ENABLED=true`), en générer une
   **nouvelle** depuis la console OpenAI et ne jamais réutiliser une clé
   ayant déjà circulé dans un livrable — révoquer immédiatement toute
   clé qui aurait fuité.

### Démarrage

```bash
docker compose --env-file deploy/production.env -f docker-compose.production.yml up -d --build
docker compose -f docker-compose.production.yml ps   # les 8 services doivent passer "healthy"
curl -fsS https://votre-domaine.tld/api/v1/ready
curl -fsS https://votre-domaine.tld/
# + tester l'upload d'une facture PDF (valide poppler-utils dans le conteneur api)
```

Le premier démarrage exécute 44 migrations Alembic avant que `api`
passe `healthy` (`start_period: 120s` sur son healthcheck) — sur un VPS
lent, surveiller `docker compose ps` quelques minutes avant de
s'inquiéter d'un état `starting`.

### Sauvegardes et restauration

```bash
# Lister les sauvegardes
docker compose -f docker-compose.production.yml exec backup ls -lh /backups

# Restaurer un dump précis (écrase la base cible — voir avertissement dans le script)
docker compose --env-file deploy/production.env -f docker-compose.production.yml \
  exec -T backup sh /scripts/restore.sh clinic_production_20260906T120000Z.dump
```

Le script `scripts/backup.sh` tourne en boucle dans le conteneur `backup` (pas de cron externe requis) et journalise chaque exécution.

### Migrations

```bash
cd api-server
ENV=development DATABASE_URL='postgresql+asyncpg://...' REDIS_URL='redis://...' alembic upgrade head
alembic current
alembic heads
```

La vérification complète de release est regroupée dans `scripts/verify_release.sh`. Elle compile l’API, applique les migrations, exécute les tests backend, installe les dépendances frontend verrouillées, exécute le contrôle TypeScript, les tests Vitest et le build Vite. Elle exige explicitement `DATABASE_URL` et `REDIS_URL` afin d’éviter une validation accidentelle sur une base SQLite ou un Redis absent.

> Le fichier `deploy/production.env.example` est un modèle uniquement. Il ne contient aucun secret utilisable et ne doit pas être utilisé tel quel en production. Aucun fichier `.env` réel n'est livré dans cette archive.
