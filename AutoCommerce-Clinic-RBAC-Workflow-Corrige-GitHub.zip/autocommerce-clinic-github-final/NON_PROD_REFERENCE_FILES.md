# Fichiers non qualifiés pour la production de ce packaging

Les éléments ci-dessous peuvent rester dans l’archive à titre de référence technique, de QA ou de recette, mais ils ne doivent pas être utilisés comme source de vérité pour le go-live mono-VPS :

- `docker-compose.staging.yml`
- `docker-compose.staging-sandbox.yml`
- `.env.local.qa`
- `QA_BROWSER_FINDINGS.md`
- `RAPPORT_REQUALIFICATION_V3_CORRIGEE.md`
- les scripts de seed et de smoke explicitement suffixés `qa`, `staging`, `demo`, `buyer` ou `sandbox`
- les tests automatisés et fixtures contenant `localhost`, `127.0.0.1`, `.local` ou des identifiants synthétiques

## Règle opérationnelle

Pour le déploiement clinique final, la source de vérité est limitée à :

- `SUPPORT_SCOPE_MONO_VPS.md`
- `.env.production.example`
- `INSTALLATION.md`
- `DEPLOYMENT.md`
- `OPERATIONS.md`
- `BACKUP_RESTORE.md`
- `ROLLBACK.md`
- `GO_LIVE_CHECKLIST.md`
- `READY_TO_GO_CERTIFICATION.md`
- `nginx-production.conf`
- `docker-compose.mono-vps.yml`
