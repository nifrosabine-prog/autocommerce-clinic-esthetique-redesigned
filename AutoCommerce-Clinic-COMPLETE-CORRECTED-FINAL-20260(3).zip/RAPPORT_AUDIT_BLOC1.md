# Rapport d’audit — Bloc 1 « Architecture cible et modèle de données »

## Verdict

**Bloc 1 partiellement respecté — validation complète refusée en l’état.**

Le projet contient un véritable cœur `EpisodePatient` et couvre correctement le scénario principal multi-professionnel, la séparation devis/factures, la séparation notes privées/partagées et la chaîne d’état d’un acte. Toutefois, plusieurs entités explicitement demandées dans le prompt Bloc 1 ne sont pas réellement rattachées à l’épisode patient, certaines sont remplacées par des équivalents non documentés dans le prompt, et les migrations n’ont pas été exécutées contre PostgreSQL dans l’archive fournie.

## Périmètre contrôlé

L’audit a porté sur les éléments suivants :

- `api-server/models/episode_core.py` ;
- `api-server/models/database.py` ;
- `api-server/alembic/versions/20260907_episode_core.py` ;
- `api-server/alembic/versions/20260908_episode_core_adjustments.py` ;
- `api-server/tests/test_episode_core_bloc1.py` ;
- `docs/BLOC1_MODELE_EPISODE_PATIENT.md` ;
- la chaîne de révisions Alembic ;
- la compilation Python statique.

Aucune modification du projet extrait n’a été effectuée.

## Résultat par critère d’acceptation

| Critère du Bloc 1 | Résultat | Éléments constatés |
|---|---|---|
| Les tables couvrent les scénarios mono-professionnel et multi-professionnel | **Partiel** | `EpisodePatient` possède plusieurs `Intervention`, chaque intervention possède plusieurs `InterventionActe`, et chaque intervention peut avoir son propre professionnel, rendez-vous et salle. Cependant, les entités photo, consentement, simulation IA, produit/lot et suivi ne sont pas rattachées au nouvel épisode. |
| Un rendez-vous ne limite plus l’épisode à un seul professionnel ou un seul acte | **Respecté** | `Intervention` est multiple par épisode ; `Intervention.rdv_id` est indépendant de `EpisodePatient.rdv_origine_id` ; plusieurs professionnels et plusieurs rendez-vous sont donc possibles. |
| Les devis sont séparés des factures | **Respecté** | Tables distinctes `devis`, `devis_lignes`, `facture_lignes`, `paiements` et `paiements_affectations`. Le versionnage des devis est également prévu. |
| Les notes privées sont séparées du résumé partagé | **Respecté** | Tables distinctes `notes_privees` et `notes_partagees`, avec archivage et FK protégées par `RESTRICT` après l’ajustement du 8 septembre. |
| Les identifiants `patient_id`, `rdv_id`, `episode_id` et `intervention_id` sont cohérents | **Partiel à respecté** | La cohérence du noyau est bonne pour épisode/intervention/rendez-vous. Elle reste incomplète pour les autres objets cliniques, qui ne portent généralement pas `episode_id`. |

## Points correctement implémentés

### 1. Pivot épisode patient

`EpisodePatient` est bien le pivot central. Il possède notamment `clinic_id`, `patient_id`, `rdv_origine_id`, un statut, l’auteur et la date d’ouverture, ainsi que les informations de clôture. La FK vers `Patient` utilise `RESTRICT`, ce qui protège l’historique clinique.

### 2. Multi-professionnel et multi-actes

La structure suivante est correcte :

```text
EpisodePatient
  └── Intervention × N
        └── InterventionActe × N
```

`Intervention` référence un professionnel et peut référencer son propre `rdv_id` et sa propre salle. Le test `test_episode_multi_intervention_multi_professionnel` couvre le scénario central.

### 3. Séparation des étapes d’un acte

`InterventionActe` distingue bien :

- proposition ;
- acceptation médicale ;
- acceptation financière ;
- paiement ;
- réalisation.

Chaque étape dispose de champs dédiés, avec horodatages et auteurs lorsque cela est pertinent. La contrainte SQL `ck_intervention_acte_realise_implique_accepte_medical` interdit la réalisation sans acceptation médicale.

### 4. Devis, facturation et paiements partiels

La séparation métier est solide. Les devis sont indépendants des factures et les paiements peuvent être répartis sur plusieurs lignes grâce à `PaiementAffectation`. La contrainte d’unicité `(paiement_id, facture_ligne_id)` est également prévue.

### 5. Notes privées et partagées

La séparation par tables est conforme à l’objectif de non-fuite des données. L’archivage (`archived_at`, `archived_by_id`) est préférable à une suppression physique. Ce point est mieux protégé dans la migration d’ajustement que dans la migration initiale.

### 6. Statuts et transitions

Les enums et méthodes `transitions_autorisees()` existent pour les prospects, épisodes, interventions, devis et paiements. Les ajustements ajoutent notamment `EN_ATTENTE_CONSENTEMENT`, `A_VALIDER` et le versionnage des devis.

## Écarts bloquants ou importants

### Écart 1 — `ActeCatalogue` n’existe pas sous ce nom

Le prompt exige explicitement une entité `ActeCatalogue`. Le projet réutilise `ActeMedical` comme catalogue partagé et ajoute `type_intervention`.

Ce choix peut être techniquement défendable pour préserver les FK existantes, mais il ne constitue pas une conformité littérale au modèle demandé sans décision d’architecture formellement acceptée. Il faut soit :

1. documenter explicitement que `ActeMedical` est l’implémentation du catalogue cible ; soit
2. introduire une abstraction ou une table `ActeCatalogue` avec stratégie de compatibilité.

### Écart 2 — `SuiviPostSeance` n’est pas rattaché à `EpisodePatient`

Le modèle existant contient `SuiviPostActe`, mais il possède `patient_id`, `dossier_id` et `seance_id`, sans `episode_id`. Le commentaire de `episode_core.py` renvoie ce rattachement au Bloc 13.

Or le Bloc 1 demande que le modèle cible définisse `SuiviPostSeance` dans l’architecture centrée sur l’épisode. En l’état, le suivi post-séance ne peut pas être retrouvé directement depuis un épisode sans logique indirecte ou migration ultérieure.

### Écart 3 — photos et simulation IA non rattachées à l’épisode/intervention

`PhotoClinic` et `SimulationIA` existent dans `models/database.py`, mais les champs observés ne fournissent pas le rattachement complet attendu au nouvel épisode :

- `patient_id` existe ;
- `episode_id` n’est pas présent ;
- `intervention_id` n’est pas présent ;
- `acte_id` n’est pas présent pour la photo ;
- la simulation référence une photo source, mais pas directement l’épisode/intervention.

Le prompt du Bloc 1 demande un modèle capable de porter les relations de l’épisode. Le fait de reporter ces rattachements à des blocs ultérieurs rend le Bloc 1 incomplet par rapport au prompt original.

### Écart 4 — consentements non rattachés à l’épisode/intervention

`Consentement` existe déjà, mais sa structure est centrée sur le patient et éventuellement l’acte. La migration Bloc 1 ne lui ajoute pas `episode_id` ni `intervention_id`.

Cela empêche de garantir au niveau du modèle la portée précise d’un consentement pour un épisode ou une intervention. C’est particulièrement important pour distinguer examen, traitement, photo, simulation IA et marketing.

### Écart 5 — produits, lots et utilisations non rattachés au nouvel épisode

Les modèles existants `ProduitInjectable`, `LotInjectable` et `UtilisationLot` existent, mais l’utilisation de lot est principalement rattachée au patient, dossier, acte et praticien. Aucun rattachement direct à `episode_id` ou `intervention_id` n’est ajouté dans les migrations Bloc 1.

Le modèle cible reste donc incomplet pour la traçabilité « produit/lot utilisé pendant cette intervention de cet épisode ».

### Écart 6 — portée multi-clinique non uniforme

Les tables racines portent `clinic_id`, mais `DevisLigne`, `FactureLigne` et `PaiementAffectation` n’en portent pas. Le projet justifie ce choix par une portée héritée du parent et impose un filtrage par jointure.

C’est acceptable comme option d’architecture, mais ce n’est pas conforme à la formulation stricte « toutes les nouvelles tables portent `clinic_id` ». Il faut conserver cette décision comme exception formelle et ajouter des tests empêchant toute requête isolée non scopée.

### Écart 7 — audit seulement structurel, pas comportemental

La table `AuditEvent` est créée, mais aucun service Bloc 1 ne garantit encore l’écriture automatique des événements pour les transitions sensibles. La documentation reporte la consolidation de l’audit au Bloc 12.

Le schéma est présent ; la règle métier « audit des actions sensibles » n’est pas démontrée dans ce lot.

### Écart 8 — migrations non validées sur PostgreSQL

La documentation reconnaît que les commandes suivantes n’ont pas été exécutées :

```bash
alembic upgrade head
alembic downgrade -1
alembic upgrade head
```

La migration `20260908_episode_core_adjustments.py` suppose notamment que PostgreSQL a généré les noms de contraintes suivants :

- `notes_privees_episode_id_fkey` ;
- `notes_privees_intervention_id_fkey` ;
- `notes_partagees_episode_id_fkey`.

Cette hypothèse doit être vérifiée sur une base PostgreSQL réelle. Une divergence de nom rendrait le downgrade ou l’upgrade d’ajustement non exécutable.

### Écart 9 — documentation de rollback devenue obsolète

La migration d’ajustement `20260908_episode_core_adjustments` est la révision suivante de `20260907_episode_core`. Dès lors, `alembic downgrade -1` depuis la tête revient à `20260907_episode_core`, pas directement à `20260904_team_audit`.

La documentation indique encore que le downgrade doit revenir à `20260904_team_audit`, ce qui n’est vrai qu’après deux downgrades depuis la tête actuelle.

## Tests et validation observés

Le projet contient un test dédié `tests/test_episode_core_bloc1.py` avec 10 scénarios annoncés, notamment :

- enregistrement runtime des tables ;
- épisode multi-intervention ;
- contrainte de réalisation ;
- affectation de paiement ;
- versionnage de devis ;
- transitions ;
- archivage des notes ;
- rôle prestataire ;
- conversion prospect-patient.

La compilation Python statique des modèles, migrations et test Bloc 1 réussit. En revanche, la suite n’a pas pu être exécutée dans l’environnement d’audit, car les dépendances d’exécution `sqlalchemy`, `pytest`, `aiosqlite` et `asyncpg` ne sont pas installées dans le bac d’audit. La validation PostgreSQL n’est donc pas établie par l’archive.

## Décision recommandée

### Statut recommandé : **À corriger avant validation du Bloc 1**

Le noyau principal peut être considéré comme **fonctionnellement avancé**, mais il ne faut pas déclarer le Bloc 1 terminé tant que les actions suivantes ne sont pas réalisées :

1. décider et documenter officiellement le remplacement de `ActeCatalogue` par `ActeMedical` ;
2. ajouter `episode_id` et, lorsque nécessaire, `intervention_id` aux consentements, photos, simulations IA, utilisations de lots et suivis post-séance, ou fournir une décision de découpage explicitement approuvée ;
3. clarifier le nom cible `SuiviPostSeance` versus `SuiviPostActe` ;
4. exécuter les migrations sur PostgreSQL depuis zéro ;
5. exécuter un cycle upgrade/downgrade complet incluant les deux migrations Bloc 1 ;
6. vérifier les noms réels des contraintes PostgreSQL ;
7. corriger la documentation de rollback ;
8. ajouter des tests de rattachement multi-clinique et des tests de portée épisode/intervention pour les entités cliniques existantes.

## Conclusion finale

**Les quatre critères d’acceptation minimaux du Bloc 1 sont globalement couverts pour le noyau `EpisodePatient` / `Intervention` / `Devis` / `Facture` / `Notes`.**

**Le Bloc 1 dans son ensemble n’est toutefois pas totalement respecté**, car le modèle cible demandé devait également intégrer de façon cohérente les consentements, photos, simulations IA, produits/lots et suivis post-séance autour de l’épisode. Ces objets existent dans l’ancien modèle, mais leur migration relationnelle vers le nouvel épisode est différée ou absente. La validation réelle des migrations PostgreSQL reste également à faire.
