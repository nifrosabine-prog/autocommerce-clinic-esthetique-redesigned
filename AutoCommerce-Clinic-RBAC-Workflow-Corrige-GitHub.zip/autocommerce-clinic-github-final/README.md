# AutoCommerce Clinic

Application de gestion pour clinique esthétique, avec frontend React/Vite et API FastAPI.

## Prérequis

Node.js 22 ou plus récent, pnpm 10, Python 3.11 ou plus récent, PostgreSQL et Redis sont nécessaires pour un environnement local complet.

## Installation

```bash
cp .env.example .env
pnpm install --frozen-lockfile
python3 -m venv .venv
. .venv/bin/activate
pip install -r api-server/requirements.txt
```

Configurez ensuite les variables de `.env`, générez de vraies clés secrètes et appliquez les migrations :

```bash
. .venv/bin/activate
cd api-server
alembic upgrade head
cd ..
pnpm check:frontend
pnpm test:frontend
pnpm build:frontend
```

Pour démarrer l’application combinée :

```bash
. .venv/bin/activate
python3 api-server/run_combined.py
```

L’application est alors disponible sur `http://localhost:3000/`.

## Validation

La suite backend se lance depuis `api-server` avec `PYTHONPATH=.` et la suite frontend depuis la racine avec `pnpm test:frontend`. Les sorties générées, dépendances, bases locales, secrets et artefacts de recette sont exclus par `.gitignore`.

## Sécurité

Ne committez jamais `.env`, une clé privée, une base locale, des données patient ou des fichiers d’upload. Utilisez les secrets du fournisseur de déploiement pour les environnements partagés.
