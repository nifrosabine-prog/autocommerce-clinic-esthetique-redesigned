# Refonte du landing page — MBA Clinic

## Synthèse

Le landing page public a été harmonisé autour de la marque **MBA Clinic**, clinique de médecine esthétique à Tunis. La refonte conserve la palette déjà utilisée par l’interface : bleu-vert profond `#172126`, beige `#f5f3ee`, ivoire `#fbfaf7` et champagne `#f4d99f` / `#d7b77a`.

Le formulaire de réservation et la logique agenda n’ont pas été modifiés. Les appels existants vers les disponibilités, les praticiens, les actes, la réservation et le rappel restent en place ; seuls le cadre éditorial, la navigation et la présentation visuelle ont été enrichis.

## Éléments ajoutés

| Élément | Intégration |
|---|---|
| Monogramme MBA | `client/public/branding/mba-clinic-monogram.png`, affiché dans l’en-tête et le pied de page |
| Photo premium | `client/public/branding/mba-clinic-waiting-room.jpg`, utilisée comme image hero avec overlay de contraste |
| Navigation | Ancres vers « Qui sommes-nous », « Nos actes », « Contact » et CTA vers `#reservation` |
| Contenu éditorial | Présentation de MBA Clinic, approche personnalisée, confidentialité, naturel et parcours de consultation |
| Nos actes | Cartes alimentées par les prestations déjà exposées par l’API publique, avec valeurs de repli non médicales si l’API est indisponible |
| Contact | Localisation Tunis, téléphone/WhatsApp public, disponibilités sur rendez-vous et lien Instagram |
| SEO | Langue française, title, meta description, Open Graph, Twitter Card et données structurées Schema.org `HealthAndBeautyBusiness` |
| Typographie | DM Sans pour le texte courant et Playfair Display pour les titres, uniquement sur le landing page |

## Informations publiques utilisées

La recherche publique a confirmé le nom **Mba Clinic**, la présence à Tunis et le numéro visible **+216 54 608 606** dans l’extrait du profil Instagram associé. Les pages Instagram et Facebook redirigeant vers une connexion, aucune adresse exacte, aucun horaire détaillé et aucune liste de traitements spécifique n’ont été inventés dans le contenu.

## Validation

Le typecheck frontend, les **69 tests frontend** et le build de production ont été exécutés avec succès. Le navigateur local confirme la présence du titre SEO, de la meta description, du JSON-LD, du monogramme, de la photo hero, des ancres et du parcours de réservation en état contrôlé lorsque le backend n’est pas lancé localement.

## Références publiques

[1]: https://www.instagram.com/mba_clinic/?hl=fr "Mba Clinic — profil Instagram public"

[2]: https://www.facebook.com/madiha.benhassenazaiez/ "Mba Clinic — présence Facebook publique"
