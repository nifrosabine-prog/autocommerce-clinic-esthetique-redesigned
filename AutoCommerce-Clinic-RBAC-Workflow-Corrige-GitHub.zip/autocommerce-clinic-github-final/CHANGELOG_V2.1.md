# CHANGELOG — MBA Clinic V2.1 améliorée

## Résumé

La V2.1 améliore la robustesse opérationnelle sans refonte UI ni changement d’architecture globale. Elle conserve le périmètre mono-clinique / mono-VPS et renforce la distinction entre information automatique et action contrôlée.

## Assistant Lina et omnicanal

Les listes de détresse médicale en français et en darija ont été enrichies avec des formulations courantes liées notamment à la respiration, aux hémorragies, aux pertes de connaissance, aux réactions allergiques sévères, aux signes neurologiques, aux convulsions et aux douleurs aiguës. La détection reste prioritaire sur le rate limit et déclenche une réponse d’urgence, une journalisation et une escalade humaine.

Les patterns d’injection couvrent désormais les tentatives d’oubli global des instructions, les messages de rôle `system/developer/assistant`, les demandes d’extraction du prompt caché, les modes jailbreak/développeur et les contournements par décodage. La réponse reste neutre, sans révéler les règles internes.

La comparaison de la fenêtre d’annulation est rendue robuste entre dates naïves et dates timezone-aware. La proposition d’annulation demeure soumise à `CANCELLATION_WINDOW_MINUTES`. Les valeurs par défaut de LLM médical, webhooks et WhatsApp restent désactivées.

## Facturation

Les calculs continuent d’utiliser `Decimal`. Les lignes sont contrôlées : prix négatif, quantité nulle ou négative, remise hors intervalle et taux de TVA hors intervalle sont rejetés. Le paiement est limité aux transitions cohérentes et à des modes de paiement connus. Une facture déjà annulée ne peut pas être repassée en paiement ; une annulation répétée est refusée et un motif explicite est obligatoire.

## Documentation et livraison

Ajout de `LIVRAISON_CLIENT.md`, `PERIMETRE_MODULES.md`, `LIMITES_ASSISTANT_IA.md` et `V21_RELEASE_MANIFEST.md`. Ces documents décrivent le périmètre, les exclusions, les conditions de go-live, les permissions attendues, les limites de Lina, les contrôles WhatsApp et les variables de sécurité par défaut.

## Non-modifications intentionnelles

Aucun multi-tenant, aucune téléconsultation complète, aucun diagnostic ou conseil médical, aucun LLM libre patient, aucune refonte UI majeure et aucun secret de production n’ont été ajoutés.

## Références internes

[1]: ./LIVRAISON_CLIENT.md "Remise client"
[2]: ./PERIMETRE_MODULES.md "Périmètre des modules"
[3]: ./LIMITES_ASSISTANT_IA.md "Limites de Lina"
[4]: ./V21_RELEASE_MANIFEST.md "Manifeste de livraison"

## Références

[1]: ./LIVRAISON_CLIENT.md "Remise client"
[2]: ./PERIMETRE_MODULES.md "Périmètre des modules"
[3]: ./LIMITES_ASSISTANT_IA.md "Limites de Lina"
[4]: ./V21_RELEASE_MANIFEST.md "Manifeste de livraison"
