# Support officiel du packaging

## Mode officiellement supporté

Ce packaging est **officiellement figé pour une seule clinique sur un seul VPS**. Le mode nominal est :

- une clinique = une instance dédiée ;
- un PostgreSQL dédié ;
- un Redis dédié ;
- API, worker, beat et frontend sur le même VPS ;
- reverse proxy Nginx sur le même VPS ;
- exposition publique limitée au frontend public, à `/api/public` et aux webhooks explicitement activés ;
- surface privée séparée par DNS privé, VPN ou ACL réseau.

## Ce qui relève du mode enterprise

Le mode `enterprise` reste présent dans le code pour compatibilité et pour des déploiements futurs, mais **n’est pas qualifié par ce packaging comme mode prêt à produire**. Relèvent du périmètre enterprise :

- multi-cliniques sur une même plateforme ;
- architecture à plusieurs environnements et plusieurs domaines gérés séparément ;
- validations d’isolement et d’exploitation inter-cliniques à l’échelle plateforme ;
- gouvernance centralisée des credentials, de l’observabilité et des egress externes ;
- procédures de rollback et restore coordonnées sur plusieurs tenants.

## Non supporté dans ce packaging

Ce packaging ne doit pas être présenté comme supportant nativement :

- le multi-tenant mutualisé prêt à l’emploi ;
- le multi-VPS ou le multi-région ;
- la haute disponibilité active/active ;
- l’autoscaling horizontal ;
- la promesse de production-ready enterprise sans preuves runtime séparées ;
- la qualification d’orchestration LLM médicale réelle si `LLM_ENABLED=false`.

## Conséquence documentaire

Toute documentation opérationnelle de cette archive doit considérer `internal_single_clinic` comme référence. Toute mention enterprise doit être présentée comme **périmètre distinct, non qualifié par ce livrable**.
