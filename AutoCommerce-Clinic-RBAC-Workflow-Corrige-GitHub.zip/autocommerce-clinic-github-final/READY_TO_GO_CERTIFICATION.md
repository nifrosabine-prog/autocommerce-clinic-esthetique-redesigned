# Statut de qualification du livrable

## Verdict de ce packaging

**Packaging finalisé pour go-live contrôlé en mono-clinique mono-VPS.**

## Règle de qualification

La mention **production ready** ne doit être utilisée qu’après existence des preuves runtime réelles sur le VPS cible :

- `docker compose up` complet ;
- migrations appliquées ;
- healthchecks OK ;
- login + MFA + refresh + logout ;
- booking public puis validation privée ;
- RBAC par rôle ;
- isolation clinique ;
- worker + beat ;
- webhook réel ou sandbox fournisseur ;
- backup chiffré + HMAC ;
- restauration isolée réussie ;
- observabilité active ;
- rollback testé ;
- checklist go-live signée.

## Ce qui est finalisé dans cette archive

- mode supporté officiellement figé : mono-clinique mono-VPS ;
- exemple `.env.production.example` minimal et strict ;
- docs installation / déploiement / opérations / backup / rollback réalignées ;
- alignement du wording assistant IA : moteur sécurisé déterministe par défaut, orchestration LLM optionnelle ;
- ajout des logs structurés et des `request_id` / `correlation_id` côté API ;
- renforcement des contrôles de cohérence `PUBLIC_CLINIC_ID` et `SOCIAL_WEBHOOK_CLINIC_ID`.

## Ce qui reste obligatoirement à produire sur le VPS cible

Les preuves runtime, de restaurabilité et d’alerting ne peuvent pas être inventées depuis l’archive. Elles doivent être exécutées, horodatées et archivées sur l’infrastructure cible avant qualification finale.
